import { getDb } from "./db";
import { 
  adminSessions, 
  notifications, 
  siteSettings, 
  announcements, 
  accessLogs, 
  bannedIps, 
  loginAttempts,
  type InsertAdminSession,
  type InsertNotification,
  type InsertAnnouncement,
  type InsertAccessLog,
  type InsertBannedIp,
  type InsertLoginAttempt,
} from "../drizzle/schema";
import { eq, desc, and, gte, sql } from "drizzle-orm";
import crypto from "crypto";

const ADMIN_USERNAME = "johnmdz";
const ADMIN_PASSWORD_HASH = crypto
  .createHash("sha256")
  .update("johnmdzup99")
  .digest("hex");

const MAX_LOGIN_ATTEMPTS = 5;
const ATTEMPT_WINDOW_MS = 15 * 60 * 1000; // 15 minutos
const SESSION_DURATION_MS = 24 * 60 * 60 * 1000; // 24 horas

// Autenticação
export async function verifyAdminCredentials(username: string, password: string): Promise<boolean> {
  if (username !== ADMIN_USERNAME) return false;
  
  const passwordHash = crypto.createHash("sha256").update(password).digest("hex");
  return passwordHash === ADMIN_PASSWORD_HASH;
}

export async function createAdminSession(ipAddress: string, userAgent?: string): Promise<string> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const token = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DURATION_MS);

  await db.insert(adminSessions).values({
    token,
    ipAddress,
    userAgent,
    expiresAt,
  });

  return token;
}

export async function verifyAdminSession(token: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  const sessions = await db
    .select()
    .from(adminSessions)
    .where(eq(adminSessions.token, token))
    .limit(1);

  if (sessions.length === 0) return false;

  const session = sessions[0];
  return new Date() < new Date(session.expiresAt);
}

export async function deleteAdminSession(token: string): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(adminSessions).where(eq(adminSessions.token, token));
}

// Login attempts & IP banning
export async function recordLoginAttempt(ipAddress: string, success: boolean): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.insert(loginAttempts).values({
    ipAddress,
    success,
    timestamp: Date.now(),
  });

  if (!success) {
    await checkAndBanIp(ipAddress);
  }
}

async function checkAndBanIp(ipAddress: string): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const cutoffTime = Date.now() - ATTEMPT_WINDOW_MS;
  
  const attempts = await db
    .select()
    .from(loginAttempts)
    .where(
      and(
        eq(loginAttempts.ipAddress, ipAddress),
        eq(loginAttempts.success, false),
        gte(loginAttempts.timestamp, cutoffTime)
      )
    );

  if (attempts.length >= MAX_LOGIN_ATTEMPTS) {
    await banIp(ipAddress, "Múltiplas tentativas de login falhadas");
  }
}

export async function isIpBanned(ipAddress: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  const banned = await db
    .select()
    .from(bannedIps)
    .where(eq(bannedIps.ipAddress, ipAddress))
    .limit(1);

  return banned.length > 0;
}

export async function banIp(ipAddress: string, reason?: string): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    await db.insert(bannedIps).values({
      ipAddress,
      reason,
    });
  } catch (error) {
    // IP já está banido
  }
}

export async function unbanIp(ipAddress: string): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(bannedIps).where(eq(bannedIps.ipAddress, ipAddress));
}

export async function getBannedIps() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(bannedIps).orderBy(desc(bannedIps.bannedAt));
}

// Notificações
export async function createNotification(data: Omit<InsertNotification, "createdAt">): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.insert(notifications).values(data);
}

export async function getRecentNotifications(limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(notifications)
    .where(eq(notifications.isGlobal, true))
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
}

export async function deleteNotification(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(notifications).where(eq(notifications.id, id));
}

// Site settings
export async function getSiteSetting(key: string): Promise<string | null> {
  const db = await getDb();
  if (!db) return null;

  const settings = await db
    .select()
    .from(siteSettings)
    .where(eq(siteSettings.key, key))
    .limit(1);

  return settings.length > 0 ? settings[0].value : null;
}

export async function setSiteSetting(key: string, value: string): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const existing = await db
    .select()
    .from(siteSettings)
    .where(eq(siteSettings.key, key))
    .limit(1);

  if (existing.length > 0) {
    await db
      .update(siteSettings)
      .set({ value })
      .where(eq(siteSettings.key, key));
  } else {
    await db.insert(siteSettings).values({ key, value });
  }
}

export async function isMaintenanceMode(): Promise<boolean> {
  const value = await getSiteSetting("maintenance_mode");
  return value === "true";
}

export async function getMaintenanceMessage(): Promise<string> {
  const message = await getSiteSetting("maintenance_message");
  return message || "O site está em manutenção. Voltaremos em breve!";
}

// Announcements
export async function createAnnouncement(data: Omit<InsertAnnouncement, "createdAt" | "updatedAt">): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.insert(announcements).values(data);
}

export async function getActiveAnnouncements() {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(announcements)
    .where(eq(announcements.isActive, true))
    .orderBy(desc(announcements.createdAt));
}

export async function getAllAnnouncements() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(announcements).orderBy(desc(announcements.createdAt));
}

export async function updateAnnouncement(id: number, data: Partial<Omit<InsertAnnouncement, "createdAt" | "updatedAt">>): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.update(announcements).set(data).where(eq(announcements.id, id));
}

export async function deleteAnnouncement(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(announcements).where(eq(announcements.id, id));
}

// Access logs
export async function logAccess(data: Omit<InsertAccessLog, "createdAt">): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.insert(accessLogs).values(data);
}

export async function getAccessLogs(limit: number = 100) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(accessLogs)
    .orderBy(desc(accessLogs.timestamp))
    .limit(limit);
}

export async function getAccessLogsByIp(ipAddress: string, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(accessLogs)
    .where(eq(accessLogs.ipAddress, ipAddress))
    .orderBy(desc(accessLogs.timestamp))
    .limit(limit);
}

export async function getAccessStats() {
  const db = await getDb();
  if (!db) return { totalVisits: 0, uniqueIps: 0, topPages: [] };

  const last24h = Date.now() - 24 * 60 * 60 * 1000;
  
  const totalVisits = await db
    .select({ count: sql<number>`count(*)` })
    .from(accessLogs)
    .where(gte(accessLogs.timestamp, last24h));

  const uniqueIps = await db
    .select({ count: sql<number>`count(distinct ${accessLogs.ipAddress})` })
    .from(accessLogs)
    .where(gte(accessLogs.timestamp, last24h));

  const topPages = await db
    .select({
      path: accessLogs.path,
      count: sql<number>`count(*)`,
    })
    .from(accessLogs)
    .where(gte(accessLogs.timestamp, last24h))
    .groupBy(accessLogs.path)
    .orderBy(desc(sql`count(*)`))
    .limit(10);

  return {
    totalVisits: totalVisits[0]?.count || 0,
    uniqueIps: uniqueIps[0]?.count || 0,
    topPages,
  };
}
