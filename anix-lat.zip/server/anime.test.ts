import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createMockContext(): TrpcContext {
  const ctx: TrpcContext = {
    user: undefined,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("anime procedures", () => {
  it("should fetch anime feed successfully", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.anime.getFeed();

    expect(result).toBeDefined();
    expect(result.status).toBe(true);
    expect(Array.isArray(result.data)).toBe(true);
  }, 10000);

  it("should accept valid anime ID for details query", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.anime.getDetails({ animeId: 1043 });

    expect(result).toBeDefined();
  });

  it("should fetch episode stream with valid episode ID", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.anime.getEpisodeStream({ episodeId: 8907 });

    expect(result).toBeDefined();
    expect(result.streams).toBeDefined();
    expect(result.episodeAnimeID).toBeDefined();
  });
});
