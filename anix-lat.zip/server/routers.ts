import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import * as betomato from "./betomato";
import * as admin from "./admin";
import { TRPCError } from "@trpc/server";

// Middleware para verificar sessão admin
const adminProcedure = publicProcedure.use(async ({ ctx, next }) => {
  const token = ctx.req.cookies?.["admin_token"];
  
  if (!token) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Admin token não fornecido" });
  }

  const isValid = await admin.verifyAdminSession(token);
  if (!isValid) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Sessão admin inválida ou expirada" });
  }

  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  anime: router({
    getFeed: publicProcedure.query(async () => {
      return await betomato.getAnimeFeed();
    }),

    getDetails: publicProcedure
      .input(z.object({ animeId: z.number() }))
      .query(async ({ input }) => {
        return await betomato.getAnimeDetails(input.animeId);
      }),

    getEpisodeStream: publicProcedure
      .input(z.object({ episodeId: z.number() }))
      .query(async ({ input }) => {
        return await betomato.getEpisodeStream(input.episodeId);
      }),

    search: publicProcedure
      .input(z.object({ query: z.string(), page: z.number().optional() }))
      .query(async ({ input }) => {
        return await betomato.searchAnimes(input.query, input.page || 0);
      }),

    getSeasonEpisodes: publicProcedure
      .input(z.object({ seasonId: z.number(), page: z.number().optional(), order: z.enum(["ASC", "DESC"]).optional() }))
      .query(async ({ input }) => {
        return await betomato.getSeasonEpisodes(input.seasonId, input.page, input.order);
      }),

    // Endpoint para download de episódios
    getDownloadUrl: publicProcedure
      .input(z.object({ 
        url: z.string(), 
        filename: z.string() 
      }))
      .query(({ input }) => {
        // Retorna URL do endpoint de download do servidor
        const encodedUrl = encodeURIComponent(input.url);
        const encodedFilename = encodeURIComponent(input.filename);
        return {
          downloadUrl: `/api/download?url=${encodedUrl}&filename=${encodedFilename}`
        };
      }),
  }),

  watchHistory: router({
    getHistory: protectedProcedure.query(async ({ ctx }) => {
      return await db.getWatchHistoryByUser(ctx.user.id);
    }),

    getProgress: protectedProcedure
      .input(z.object({ episodeId: z.number() }))
      .query(async ({ ctx, input }) => {
        return await db.getWatchProgressForEpisode(ctx.user.id, input.episodeId);
      }),

    updateProgress: protectedProcedure
      .input(
        z.object({
          animeId: z.number(),
          episodeId: z.number(),
          episodeNumber: z.number(),
          watchProgress: z.number(),
          totalDuration: z.number(),
          completed: z.boolean(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await db.upsertWatchHistory({
          userId: ctx.user.id,
          animeId: input.animeId,
          episodeId: input.episodeId,
          episodeNumber: input.episodeNumber,
          watchProgress: input.watchProgress,
          totalDuration: input.totalDuration,
          completed: input.completed,
        });
        return { success: true };
      }),
  }),

  favorites: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getFavoritesByUser(ctx.user.id);
    }),

    check: protectedProcedure
      .input(z.object({ animeId: z.number() }))
      .query(async ({ ctx, input }) => {
        return await db.isFavorite(ctx.user.id, input.animeId);
      }),

    add: protectedProcedure
      .input(z.object({ animeId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.addFavorite({
          userId: ctx.user.id,
          animeId: input.animeId,
        });
        return { success: true };
      }),

    remove: protectedProcedure
      .input(z.object({ animeId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.removeFavorite(ctx.user.id, input.animeId);
        return { success: true };
      }),
  }),

  admin: router({
    // Autenticação
    login: publicProcedure
      .input(z.object({ username: z.string(), password: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const ipAddress = ctx.req.ip || ctx.req.socket.remoteAddress || "unknown";

        // Verificar se IP está banido
        const isBanned = await admin.isIpBanned(ipAddress);
        if (isBanned) {
          throw new TRPCError({ 
            code: "FORBIDDEN", 
            message: "Seu IP foi banido devido a múltiplas tentativas de login falhadas" 
          });
        }

        // Verificar credenciais
        const isValid = await admin.verifyAdminCredentials(input.username, input.password);
        
        // Registrar tentativa
        await admin.recordLoginAttempt(ipAddress, isValid);

        if (!isValid) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Credenciais inválidas" });
        }

        // Criar sessão
        const userAgent = ctx.req.headers["user-agent"];
        const token = await admin.createAdminSession(ipAddress, userAgent);

        // Definir cookie
        ctx.res.cookie("admin_token", token, {
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
          sameSite: "lax",
          maxAge: 24 * 60 * 60 * 1000, // 24 horas
        });

        return { success: true };
      }),

    logout: adminProcedure.mutation(async ({ ctx }) => {
      const token = ctx.req.cookies?.["admin_token"];
      if (token) {
        await admin.deleteAdminSession(token);
      }
      ctx.res.clearCookie("admin_token");
      return { success: true };
    }),

    verifySession: publicProcedure.query(async ({ ctx }) => {
      const token = ctx.req.cookies?.["admin_token"];
      if (!token) return { isValid: false };
      
      const isValid = await admin.verifyAdminSession(token);
      return { isValid };
    }),

    // Notificações
    sendNotification: adminProcedure
      .input(z.object({
        title: z.string(),
        message: z.string(),
        type: z.enum(["info", "warning", "error", "success"]).optional(),
      }))
      .mutation(async ({ input }) => {
        await admin.createNotification({
          title: input.title,
          message: input.message,
          type: input.type || "info",
          isGlobal: true,
        });
        return { success: true };
      }),

    getNotifications: adminProcedure.query(async () => {
      return await admin.getRecentNotifications(100);
    }),

    deleteNotification: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await admin.deleteNotification(input.id);
        return { success: true };
      }),

    // Site settings
    setMaintenanceMode: adminProcedure
      .input(z.object({ enabled: z.boolean(), message: z.string().optional() }))
      .mutation(async ({ input }) => {
        await admin.setSiteSetting("maintenance_mode", input.enabled.toString());
        if (input.message) {
          await admin.setSiteSetting("maintenance_message", input.message);
        }
        return { success: true };
      }),

    getMaintenanceStatus: adminProcedure.query(async () => {
      const enabled = await admin.isMaintenanceMode();
      const message = await admin.getMaintenanceMessage();
      return { enabled, message };
    }),

    // Announcements
    createAnnouncement: adminProcedure
      .input(z.object({
        title: z.string(),
        message: z.string(),
        type: z.enum(["info", "warning", "error", "success"]).optional(),
      }))
      .mutation(async ({ input }) => {
        await admin.createAnnouncement({
          title: input.title,
          message: input.message,
          type: input.type || "info",
          isActive: true,
        });
        return { success: true };
      }),

    getAnnouncements: adminProcedure.query(async () => {
      return await admin.getAllAnnouncements();
    }),

    updateAnnouncement: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        message: z.string().optional(),
        type: z.enum(["info", "warning", "error", "success"]).optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await admin.updateAnnouncement(id, data);
        return { success: true };
      }),

    deleteAnnouncement: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await admin.deleteAnnouncement(input.id);
        return { success: true };
      }),

    // Access logs
    getAccessLogs: adminProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ input }) => {
        return await admin.getAccessLogs(input.limit || 100);
      }),

    getAccessStats: adminProcedure.query(async () => {
      return await admin.getAccessStats();
    }),

    // IP banning
    getBannedIps: adminProcedure.query(async () => {
      return await admin.getBannedIps();
    }),

    banIp: adminProcedure
      .input(z.object({ ipAddress: z.string(), reason: z.string().optional() }))
      .mutation(async ({ input }) => {
        await admin.banIp(input.ipAddress, input.reason);
        return { success: true };
      }),

    unbanIp: adminProcedure
      .input(z.object({ ipAddress: z.string() }))
      .mutation(async ({ input }) => {
        await admin.unbanIp(input.ipAddress);
        return { success: true };
      }),
  }),

  // Public endpoints para notificações e avisos
  public: router({
    getNotifications: publicProcedure.query(async () => {
      return await admin.getRecentNotifications(10);
    }),

    getActiveAnnouncements: publicProcedure.query(async () => {
      return await admin.getActiveAnnouncements();
    }),

    getMaintenanceStatus: publicProcedure.query(async () => {
      const enabled = await admin.isMaintenanceMode();
      const message = await admin.getMaintenanceMessage();
      return { enabled, message };
    }),
  }),

  // Chat Global
  chat: router({
    getMessages: publicProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ input }) => {
        return await db.getChatMessages(input.limit || 100);
      }),

    sendMessage: publicProcedure
      .input(z.object({
        username: z.string().min(1).max(100),
        message: z.string().max(500).optional(),
        userAvatar: z.string().max(500).optional(),
        mediaType: z.enum(["text", "image", "gif", "audio"]).optional(),
        mediaUrl: z.string().max(500).optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.sendChatMessage(
          input.username,
          input.message,
          input.userAvatar,
          input.mediaType,
          input.mediaUrl
        );
      }),
  }),
});

export type AppRouter = typeof appRouter;
