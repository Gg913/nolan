import axios from "axios";

const BETOMATO_API_URL = "https://edge.betomato.com/v2";
const BETOMATO_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTU1NTAyMDgsInV1aWQiOiI1MWYwNWMxZC0xYWQwLTQxOWItOWE5MC1iOTljZGI3MGU4YTQiLCJpYXQiOjE3Njk3MTMwMzN9.tCqgd5IhVtw4M11mGGJ_d9oDoRj7nPJlW4MMBncp7z0";

const betomatoClient = axios.create({
  baseURL: BETOMATO_API_URL,
  timeout: 10000, // 10 segundos - falha rápido se API não responder
  headers: {
    "Authorization": `Bearer ${BETOMATO_TOKEN}`,
    "Accept": "application/json, text/plain, */*",
    "Accept-Encoding": "gzip, deflate",
    "X-App": "1.4.3",
    "User-Agent": "okhttp/4.11.0",
  },
});

export interface AnimeFeedResponse {
  status: boolean;
  status_code: number;
  remote_settings: {
    block_screenshots: boolean;
  };
  data: Array<{
    type: number;
    title?: string;
    data?: Array<{
      anime_id?: number;
      thumbnail?: string;
      tag_id?: number;
      ep_id?: number;
      ep_anime_id?: number;
      anime_name?: string;
      ep_name?: string;
      dubbed?: boolean;
    }>;
    watch_progress?: number;
    playback_offset?: number;
    episode_id?: number;
    ep_anime_id?: number;
    ep_season_id?: number;
    ep_number?: number;
    ep_name?: string | null;
    ep_thumbnail?: string | null;
    ep_lenght_minutes?: number;
    hyper_title?: string;
    banner?: string;
    text?: string;
    tags?: string;
    year?: string;
    rating?: string;
    anime_id?: number;
  }>;
}

export interface AnimeDetailsResponse {
  anime_details: {
    anime_id: number;
    anime_name: string;
    anime_description: string;
    anime_parental_rating: string;
    release_day: string;
    anime_episodes: number;
    anime_date: string;
    anime_cover_url: string;
    anime_cape_url: string;
    anime_banner_url: string;
    anime_genre: string;
    dub_available: boolean;
  };
  liked: boolean;
  favorited: boolean;
  notify: boolean;
  notify_capable: boolean;
  comments_count: number;
  anime_seasons: Array<{
    season_id: number;
    season_name: string;
    season_number: number;
    season_dubbed: number;
    episodes?: Array<{
      ep_id: number;
      ep_name: string;
      ep_number: number;
      ep_anime_id: number;
      ep_season_id: number;
      ep_thumbnail: string;
      ep_description: string | null;
      watch_progress: number | null;
      ep_lenght_minutes: number;
    }>;
  }>;
}

export interface EpisodeStreamResponse {
  streams: {
    shd: string | null;
    mhd: string | null;
    fhd: string | null;
  };
  episodeType: number;
  episodeAnimeID: number;
  episodeNumber: number;
  seasonNumber?: number;
  episodeName: string;
  episodeHasNext: boolean;
  nextEpisodeID: number | null;
  nextEpisodeTitle: string | null;
  nextEpisodeData: {
    episodeID: number;
    episodeName: string;
    episodeThumbnail: string;
  } | null;
  showInterstitial: boolean;
  customInterstitial: boolean;
  cast: {
    castContentType: string;
    castStreamType: number;
    castAllowed: boolean;
  };
}

export async function getAnimeFeed(): Promise<AnimeFeedResponse> {
  const requestTime = Date.now();
  const response = await betomatoClient.get("/animes/feed", {
    headers: {
      "Request-Time": requestTime.toString(),
    },
  });
  return response.data;
}

export async function getAnimeDetails(animeId: number): Promise<AnimeDetailsResponse> {
  const response = await betomatoClient.get(`/anime/${animeId}`);
  return response.data;
}

export async function getEpisodeStream(episodeId: number): Promise<EpisodeStreamResponse> {
  const response = await betomatoClient.get(`/anime/episode/${episodeId}/stream`, {
    headers: {
      "User-Agent": "tomato-android",
      "Content-Type": "application/json",
    },
  });
  return response.data;
}

export async function searchAnimes(query: string, page: number = 0): Promise<any> {
  const requestTime = Date.now();
  const response = await betomatoClient.post("/content/search", {
    token: BETOMATO_TOKEN,
    search: query,
    content_type: "all",
    page,
  }, {
    headers: {
      "Content-Type": "application/json",
      "Request-Time": requestTime.toString(),
    },
  });
  return response.data;
}

export async function getSeasonEpisodes(seasonId: number, page: number = 0, order: "ASC" | "DESC" = "ASC"): Promise<any> {
  const requestTime = Date.now();
  // Episódios não usam /v2, então fazemos chamada direta
  const response = await axios.post(`https://edge.betomato.com/season/${seasonId}/episodes`, {
    token: BETOMATO_TOKEN,
    page,
    order,
  }, {
    timeout: 10000, // 10 segundos
    headers: {
      "Authorization": `Bearer ${BETOMATO_TOKEN}`,
      "Accept": "application/json, text/plain, */*",
      "Accept-Encoding": "gzip, deflate",
      "Content-Type": "application/json",
      "Request-Time": requestTime.toString(),
      "User-Agent": "okhttp/4.11.0",
    },
  });
  return response.data;
}
