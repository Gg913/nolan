import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, watchHistory, InsertWatchHistory, favorites, InsertFavorite, globalChat, InsertGlobalChatMessage } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function upsertWatchHistory(data: InsertWatchHistory) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert watch history: database not available");
    return;
  }

  try {
    await db.insert(watchHistory).values(data).onDuplicateKeyUpdate({
      set: {
        watchProgress: data.watchProgress,
        totalDuration: data.totalDuration,
        completed: data.completed,
        lastWatchedAt: new Date(),
        updatedAt: new Date(),
      },
    });
  } catch (error) {
    console.error("[Database] Failed to upsert watch history:", error);
    throw error;
  }
}

export async function getWatchHistoryByUser(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get watch history: database not available");
    return [];
  }

  return await db
    .select()
    .from(watchHistory)
    .where(eq(watchHistory.userId, userId))
    .orderBy(desc(watchHistory.lastWatchedAt));
}

export async function getWatchProgressForEpisode(userId: number, episodeId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get watch progress: database not available");
    return null;
  }

  const result = await db
    .select()
    .from(watchHistory)
    .where(and(eq(watchHistory.userId, userId), eq(watchHistory.episodeId, episodeId)))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function addFavorite(data: InsertFavorite) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot add favorite: database not available");
    return;
  }

  try {
    await db.insert(favorites).values(data);
  } catch (error) {
    console.error("[Database] Failed to add favorite:", error);
    throw error;
  }
}

export async function removeFavorite(userId: number, animeId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot remove favorite: database not available");
    return;
  }

  try {
    await db.delete(favorites).where(and(eq(favorites.userId, userId), eq(favorites.animeId, animeId)));
  } catch (error) {
    console.error("[Database] Failed to remove favorite:", error);
    throw error;
  }
}

export async function getFavoritesByUser(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get favorites: database not available");
    return [];
  }

  return await db.select().from(favorites).where(eq(favorites.userId, userId)).orderBy(desc(favorites.createdAt));
}

export async function isFavorite(userId: number, animeId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check favorite: database not available");
    return false;
  }

  const result = await db
    .select()
    .from(favorites)
    .where(and(eq(favorites.userId, userId), eq(favorites.animeId, animeId)))
    .limit(1);

  return result.length > 0;
}

// Global Chat
export async function getChatMessages(limit: number = 100) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get chat messages: database not available");
    return [];
  }

  return await db
    .select()
    .from(globalChat)
    .orderBy(desc(globalChat.timestamp))
    .limit(limit)
    .then(messages => messages.reverse()); // Reverse to show oldest first
}

export async function sendChatMessage(
  username: string,
  message?: string,
  userAvatar?: string,
  mediaType?: string,
  mediaUrl?: string
) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot send chat message: database not available");
    return null;
  }

  const chatMessage: InsertGlobalChatMessage = {
    username,
    message: message || null,
    userAvatar: userAvatar || null,
    mediaType: mediaType || 'text',
    mediaUrl: mediaUrl || null,
    timestamp: Date.now(),
  };

  await db.insert(globalChat).values(chatMessage);
  
  return chatMessage;
}
