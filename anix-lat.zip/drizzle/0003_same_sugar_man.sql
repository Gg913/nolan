CREATE TABLE `global_chat` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(100) NOT NULL,
	`message` text NOT NULL,
	`timestamp` bigint NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `global_chat_id` PRIMARY KEY(`id`)
);
