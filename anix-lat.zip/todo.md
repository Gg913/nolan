# ANIX-LAT - TODO List

## 1. Botões de Navegação Permanentes
- [x] Remover botão temporário que aparece nos últimos 10 segundos
- [x] Adicionar botão "Próximo Episódio" (se houver)
- [x] Posicionar abaixo do player, sempre visível
- [x] Design consistente com o resto do site
- [x] API não fornece previousEpisodeID, apenas nextEpisodeID

## 2. Seção de Informações do Anime
- [x] Sinopse completa do anime
- [x] Gêneros (badges)
- [x] Data de lançamento
- [x] Classificação etária
- [x] Dia de lançamento
- [x] Número total de episódios
- [x] Layout organizado e responsivo

## 3. Painel de Administração (/admin)

### 3.1 Autenticação Admin
- [x] Sistema de login seguro (credenciais criptografadas no backend)
- [x] Sessão admin com JWT
- [x] Rate limiting para tentativas de login
- [x] Sistema de banimento automático por IP (após múltiplas tentativas falhas)
- [x] Middleware de proteção para rotas admin

### 3.2 Sistema de Notificações
- [x] Enviar notificações broadcast para todos os usuários
- [x] Notificações aparecem no ícone do sininho (Navbar)
- [x] Armazenar notificações no banco de dados
- [x] Dropdown de notificações no frontend

### 3.3 Modo Manutenção
- [x] Toggle para ativar/desativar modo manutenção
- [x] Página de manutenção personalizada
- [x] Middleware que bloqueia acesso ao site (exceto admin)
- [x] Mensagem customizável de manutenção

### 3.4 Sistema de Avisos
- [x] Criar avisos que aparecem em dialog na home
- [x] CRUD de avisos (criar, editar, deletar)
- [x] Avisos com título, mensagem e tipo (info/warning/error/success)
- [x] Controle de visibilidade dos avisos

### 3.5 Logs de Acesso
- [x] Registrar acessos ao site (IP, página, timestamp, user agent)
- [x] Dashboard de logs em tempo real
- [x] Estatísticas de acesso (páginas mais visitadas, IPs únicos, visitas 24h)

### 3.6 Sistema de Banimento
- [x] Lista de IPs banidos no banco de dados
- [x] Middleware que bloqueia IPs banidos
- [x] Interface para gerenciar banimentos (adicionar/remover)
- [x] Banimento automático após 5 tentativas de login falhas em 15 minutos

### 3.7 Dashboard Admin
- [x] Página /admin com layout profissional
- [x] Seção de notificações broadcast
- [x] Seção de modo manutenção
- [x] Seção de avisos
- [x] Seção de logs de acesso
- [x] Seção de gerenciamento de banimentos
- [x] Estatísticas gerais do site

## 4. Correções de Bugs

### 4.1 Sistema de Cookies Admin
- [x] Instalar cookie-parser no Express
- [x] Configurar middleware de cookies antes das rotas
- [x] Corrigir acesso a ctx.req.cookies no backend

### 4.2 Verificação de Sessão Admin
- [x] verifySession deve ser publicProcedure (não adminProcedure)
- [x] Permitir verificação de sessão sem token (retornar isValid: false)
- [x] Adicionar enabled: false para queries admin quando não autenticado

### 4.3 Middlewares de Manutenção e Banimento
- [x] Corrigir carregamento infinito quando modo manutenção está ativo
- [x] Corrigir carregamento infinito quando IP está banido
- [x] Garantir que middlewares assíncronos funcionem corretamente
- [x] Remover next() duplo após enviar resposta HTML

### 4.4 Middlewares Bloqueando API com HTML
- [x] Middlewares retornando HTML para requisições API
- [x] Frontend recebendo "Unexpected token '<'" ao invés de JSON
- [x] Detectar requisições API e retornar JSON error ao invés de HTML
- [x] Permitir requisições /api/trpc passar pelos middlewares normalmente
- [x] Adicionar helper isApiRequest() para detectar requisições /api/
- [x] Retornar JSON com error.code e error.message para APIs

## 5. Sistema de Progresso e Paginação

### 5.1 Sistema de Progresso do Usuário
- [x] Criar hook useWatchProgress para gerenciar progresso no localStorage
- [x] Salvar tempo assistido (segundos) de cada episódio
- [x] Estrutura: { animeId: { episodeId: { progress: seconds, timestamp, duration, episodeNumber, etc } } }
- [x] Atualizar progresso automaticamente durante reprodução do vídeo (a cada 5s)
- [x] Marcar episódio como "assistido" quando passar de 90% do tempo

### 5.2 Paginação de Episódios
- [x] Modificar requisição de episódios para usar parâmetro "page"
- [x] Implementar botão "Mostrar mais episódios" no final da lista
- [x] Incrementar page +1 apenas quando usuário clicar no botão
- [x] Carregar até não haver mais resultados (resposta vazia ou < 20 itens)
- [x] Manter episódios já carregados na lista (append, não replace)
- [x] Mostrar indicador de "Assistido" e barra de progresso nos episódios

### 5.3 Continue Assistindo na Home
- [x] Criar seção "Continue Assistindo" na Home
- [x] Mostrar animes com progresso salvo (até 6 itens)
- [x] Exibir episódio e minuto:segundo exato onde parou
- [x] Barra de progresso visual mostrando % assistido
- [x] Clicar leva direto ao episódio no tempo salvo (query param ?t=)
- [x] Filtrar episódios já 100% assistidos (não mostrar)

### 4.5 Bug na Funcionalidade de Pesquisa
- [x] Pesquisa não funciona após primeira busca
- [x] Input não sincroniza com URL/estado
- [x] Necessário pesquisar pela URL ao invés do input
- [x] Resetar estado corretamente entre pesquisas
- [x] Adicionar useEffect no Navbar para sincronizar searchQuery com URL

## 6. Correções e Melhorias UX

### 6.1 Bug de Pesquisa - Resultados Não Atualizam
- [x] URL muda mas resultados não atualizam
- [x] Query tRPC não está sendo re-executada
- [x] Forçar invalidate ou usar location como dependência
- [x] Adicionar setDebouncedQuery no useEffect de location

### 6.2 Navbar Mobile
- [x] Mostrar ícone de notificações (sininho) no mobile
- [x] Mostrar ícone de perfil no mobile
- [x] Ajustar layout responsivo
- [x] Remover hidden lg:flex dos botões

### 6.3 Redesign da Página Profile
- [x] Melhorar design visual da página /profile
- [x] Layout mais profissional e organizado
- [x] Adicionar informações relevantes do usuário
- [x] Hero header com gradiente
- [x] Cards de estatísticas com hover effects
- [x] Integração com useWatchProgress
- [x] Design consistente com tema Netflix

### 6.4 VideoPlayer Bugado
- [x] Player reseta do nada durante reprodução
- [x] Player trava e não passa nada
- [x] Refazer player com controles mais estáveis
- [x] Adicionar botão play grande no centro antes de iniciar
- [x] Melhorar design dos controles
- [x] Adicionar loading spinner
- [x] Melhorar gerenciamento de eventos (play/pause/waiting/canplay)
- [x] Separar timeUpdate callback em interval de 5s
- [x] Adicionar estado hasStarted para controlar botão inicial
- [x] Melhorar responsividade dos controles

## 7. Correções Críticas de Player e Pesquisa

### 7.1 Bug de Pesquisa Navbar (Persistente)
- [x] Navbar atualiza URL mas não muda resultados
- [x] Forçar navegação completa ou invalidate query
- [x] Testar múltiplas pesquisas seguidas
- [x] Usar window.location.href para forçar reload quando já na página search

### 7.2 Botão Play Não Funciona
- [x] Botão play central não responde ao clique
- [x] Corrigir event handlers do VideoPlayer
- [x] Testar em diferentes estados (loading, paused, playing)
- [x] Implementar autoplay automático

### 7.3 Autoplay e Carregamento Automático
- [x] Implementar autoplay quando video carregar
- [x] Remover necessidade de clicar para iniciar
- [x] Manter botão play apenas como fallback visual
- [x] Autoplay ativado em MANIFEST_PARSED

### 7.4 Player Resetando (Sistema de Salvamento)
- [x] Player reseta porque salvamento muda currentTime
- [x] Implementar salvamento passivo (apenas leitura de timeupdate)
- [x] NUNCA modificar video.currentTime durante salvamento
- [x] Salvar progresso a cada 1 segundo (não 5s)
- [x] Aplicar initialTime apenas UMA VEZ no início
- [x] Usar ref para controlar se initialTime já foi aplicado
- [x] Callback onTimeUpdate totalmente passivo

### 7.5 Redesign Player Profissional
- [x] Design mais leve e profissional
- [x] Controles minimalistas
- [x] Animações suaves
- [x] Melhor responsividade
- [x] Progress bar com gradiente dinâmico
- [x] Thumb da progress bar aparece apenas no hover
- [x] Loading spinner com backdrop blur
- [x] Controles com espaçamento otimizado

## 8. Nova Atualização - Correções e Melhorias

### 8.1 Botão Play Central Não Funciona
- [x] Botão no centro do player não clica
- [x] Corrigir event handlers e z-index
- [x] Garantir que onClick seja registrado
- [x] Adicionar z-10 e pointer-events-auto

### 8.2 Player Resetando ao Sair da Página
- [x] Player reseta quando sai da página Watch
- [x] Implementar cleanup correto no useEffect
- [x] Adicionar timeout de carregamento (evitar infinito)
- [x] Dois estados de loading para cada página
- [x] Timeout de 10s com botão "Tentar novamente"

### 8.3 Atualização Automática de Progresso
- [x] Progresso só aparece quando volta à página
- [x] Atualizar lista "Continue Assistindo" em tempo real
- [x] Refletir mudanças imediatamente no Profile
- [x] Refletir mudanças imediatamente na Home
- [x] Usar state management ou forçar re-render
- [x] Expor progressData do hook para reatividade
- [x] Adicionar progressData como dependência no useEffect

### 8.4 Paginação de Busca
- [x] Adicionar parâmetro "page" na API de search
- [x] Implementar botão "Mostrar mais animes"
- [x] Carregar e acumular resultados incrementalmente
- [x] Atualizar backend betomato.ts para suportar page (já existia)
- [x] Atualizar frontend Search.tsx com paginação
- [x] Atualizar procedure search no routers.ts
- [x] Detectar fim dos resultados (menos de 20 itens)

## 9. Correções de Bugs e Ajustes de Design

### 9.1 Episódios Sumindo ao Voltar
- [x] Quando volta da página Watch, episódios desaparecem
- [x] Mensagem "Nenhum episódio encontrado" aparece incorretamente
- [x] Problema de estado/cache ao navegar entre páginas
- [x] Preservar estado dos episódios carregados
- [x] Remover reset de allEpisodes ao fechar temporada

### 9.2 Mudar Tema de Vermelho para Azul
- [x] Alterar cores primárias do vermelho para azul
- [x] Atualizar index.css com nova paleta
- [x] Manter consistência em todos os componentes
- [x] Ajustar gradientes e acentos
- [x] Mudar de oklch(0.577 0.245 27.325) para oklch(0.6 0.22 250)

### 9.3 Continuar Onde Parou Resetando
- [x] Às vezes reseta para 0 ao invés de continuar do tempo salvo
- [x] Verificar aplicação do initialTime no VideoPlayer
- [x] Garantir que tempo salvo seja aplicado corretamente
- [x] Prevenir reset acidental do progresso
- [x] Resetar initialTime para 0 antes de carregar novo progresso

### 9.4 Remover "Explorar" do Navbar
- [x] Remover link "Explorar" do menu de navegação
- [x] Ajustar layout do navbar após remoção
- [x] Manter apenas "Início" no menu principal

## 10. Ajustes Finais de Cor, Query Parameter e Auto-Reload

### 10.1 Substituir Todas Cores Vermelhas por Azul
- [x] Procurar todas ocorrências de vermelho nos componentes
- [x] Substituir bg-red, text-red, border-red por azul
- [x] Verificar gradientes com vermelho
- [x] Atualizar todas as cores hardcoded
- [x] Substituídas 19 ocorrências em 6 arquivos

### 10.2 Query Parameter ?t= Não Funciona
- [x] Watch não está lendo parâmetro ?t= da URL
- [x] Implementar leitura de URLSearchParams no Watch.tsx
- [x] Aplicar tempo inicial baseado no parâmetro ?t=
- [x] Testar /watch/5030?t=120 (deve começar em 2min)
- [x] Prioridade: ?t= da URL > localStorage

### 10.3 Auto-Reload Após 3s de Loading
- [x] Implementar tentativa automática de reload
- [x] Detectar quando loading demora mais de 3 segundos
- [x] Recarregar página automaticamente
- [x] Limitar número de tentativas (máximo 3x)
- [x] Resetar contador quando carregar com sucesso

## 11. Responsividade Mobile

### 11.1 Banner e Foto do Anime Estranhos no Mobile
- [x] Banner e foto ficam estranhos na página de episódios (mobile)
- [x] Ajustar tamanhos e proporções para telas pequenas
- [x] Corrigir layout responsivo do AnimeDetails.tsx
- [x] Testar em diferentes tamanhos de tela mobile
- [x] Reduzir tamanho da foto: w-28 h-40 (mobile) vs w-40 h-60 (desktop)
- [x] Aumentar altura do banner: h-[50vh] (mobile) para melhor visualização
- [x] Adicionar object-center no banner para centralizar imagem
- [x] Adicionar flex-shrink-0 na foto para evitar compressão
- [x] Reduzir gaps e padding para mobile

## 12. Melhorias na Home

### 12.1 Continue Assistindo - Scroll Horizontal
- [x] Limitar a 10 episódios no máximo
- [x] Implementar scroll horizontal (arrastar de lado)
- [x] Remover grid vertical atual
- [x] Adicionar indicadores de scroll se necessário
- [x] Usar flex com overflow-x-auto e scrollbar-hide
- [x] Adicionar snap-x snap-mandatory para scroll suave
- [x] Cards com largura fixa: w-40 md:w-48

### 12.2 Capas Retangulares
- [x] Mudar proporção das capas em "Lançamentos Recentes"
- [x] Mudar proporção das capas em "Em Alta"
- [x] Usar formato mais largo (16:9 ou similar)
- [x] Ajustar aspect-ratio das imagens
- [x] Novos tamanhos: small (w-36 h-20), medium (w-44 h-24), large (w-56 h-32)
- [x] Adicionar object-center para centralizar imagens

## 13. Ajustes de Profile e Capas

### 13.1 Profile - Mostrar Todos Animes
- [x] Remover limite de 6 animes no Profile
- [x] Mostrar TODOS os animes que está assistindo
- [x] Manter scroll horizontal ou usar grid (usando grid)

### 13.2 Informação de Temporada + Episódio
- [x] Adicionar "Temporada X - EP Y" nos cards de Continue Assistindo
- [x] Salvar seasonNumber no localStorage junto com progresso
- [x] Exibir informação de forma clara e visível
- [x] Adicionar seasonNumber ao EpisodeProgress interface
- [x] Calcular seasonNumber a partir do animeData no Watch.tsx
- [x] Exibir "T{seasonNumber} - EP {episodeNumber}" na Home e Profile

### 13.3 Reverter Formato de Capas
- [x] Identificar quais seções são "Lançamentos" e "Em Alta"
- [x] Manter formato retangular APENAS para essas duas seções
- [x] Reverter todas as outras seções para formato vertical (2:3)
- [x] Criar prop "format" no AnimeCard para controlar proporção
- [x] Adicionar prop format ao AnimeCarousel
- [x] Detectar automaticamente formato baseado no título da seção
- [x] Vertical: w-32 h-48 (medium), Horizontal: w-44 h-24 (medium)

## 14. Correções do Profile

### 14.1 Animes Recentes Não Aparecem Completos
- [x] Cards de animes recentes cortados ou não aparecem completos
- [x] Corrigir layout/overflow dos cards
- [x] Garantir que todos os cards sejam visíveis
- [x] Mudar grid de lg:grid-cols-6 para lg:grid-cols-4 xl:grid-cols-5

### 14.2 Número Incorreto de Animes
- [x] Mostra número maior (ex: mostra mais que 4 quando são apenas 4)
- [x] Verificar contador de animes em progresso
- [x] Corrigir lógica de contagem
- [x] Usar continueWatching.length ao invés de contar todos episódios

### 14.3 Botão para Remover Animes Individuais
- [x] Adicionar botão X ou ícone de lixeira em cada card
- [x] Implementar função removeProgress no useWatchProgress
- [x] Confirmar remoção com toast/feedback visual
- [x] Botão aparece apenas no hover com opacity-0/100
- [x] Usa Trash2 icon com bg-black/80 hover:bg-blue-600

### 14.4 Limpar Dados Locais Completo
- [x] Botão "Limpar dados" só apaga favoritos
- [x] Deve apagar TODOS os dados: progresso, favoritos, etc
- [x] Limpar todas as chaves do localStorage relacionadas ao app
- [x] Corrigido para usar anix_watch_progress ao invés de watch_progress

## 15. Melhorias Profile e Player Estilo Netflix

### 15.1 Profile - Scroll Horizontal
- [x] Mudar animes em progresso para scroll horizontal
- [x] Mudar favoritos para scroll horizontal
- [x] Remover grid vertical atual
- [x] Adicionar scrollbar-hide
- [x] Usar flex com overflow-x-auto
- [x] Adicionar snap-x snap-mandatory
- [x] Mostrar TODOS os animes (sem limite)

### 15.2 Player Estilo Netflix - Preview Seekbar
- [x] Mostrar preview de tempo ao arrastar seekbar
- [x] Tooltip com tempo formatado (MM:SS)
- [x] Posicionar tooltip acima do cursor
- [x] Tooltip com bg-black/95 e pointer-events-none

### 15.3 Player - Controle de Velocidade
- [x] Adicionar botão de velocidade
- [x] Opções: 0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x
- [x] Dropdown menu estilizado
- [x] Salvar velocidade selecionada
- [x] Menu com bg-black/95 backdrop-blur-sm
- [x] Highlight da velocidade atual em azul

### 15.4 Player - Controles Auto-Hide
- [x] Clicar no centro NÃO pausa, apenas toggle controles
- [x] Controles aparecem ao mover mouse
- [x] Controles aparecem ao clicar na tela
- [x] Controles somem após 3s de inatividade
- [x] Cursor some junto com controles
- [x] handleVideoClick apenas toggle showControls
- [x] style={{ cursor: showControls ? 'default' : 'none' }}

### 15.5 Player - Design Netflix
- [x] Gradiente suave nos controles
- [x] Botões mais espaçados e maiores
- [x] Animações suaves de fade
- [x] Progress bar mais fina e elegante
- [x] Gradiente from-black/90 via-transparent to-black/40
- [x] Thumb da seekbar aparece apenas no hover (scale-0 -> scale-100)
- [x] Spacing adequado entre botões (gap-1)
- [x] Transition duration-300 nos controles

## 16. BUG CRÍTICO - Player Reiniciando

### 16.1 Player Fica Reiniciando Constantemente
- [x] Player reinicia toda hora durante reprodução
- [x] Impossível assistir normalmente
- [x] Provável causa: re-renders constantes do componente
- [x] Verificar useEffect dependencies
- [x] Verificar se showControls está causando re-mount
- [x] Remover qualquer código que force remount do video element
- [x] Removido initialTime das dependencies do useEffect HLS
- [x] initialTime agora aplicado apenas UMA VEZ no MANIFEST_PARSED

## 16. Melhorias de Controles Mobile

### 16.1 Toggle de Controles por Toque
- [x] Melhorar controles do player no mobile: toggle de controles por toque (aparecer/sumir)
- [x] Clicar/tocar na tela deve mostrar controles se estiverem escondidos
- [x] Clicar/tocar novamente deve esconder controles
- [x] Garantir que funciona bem em touch events

### 16.2 Fullscreen Horizontal Automático
- [x] Implementar fullscreen horizontal automático no mobile (landscape orientation lock)
- [x] Quando entrar em fullscreen no mobile, forçar orientação horizontal
- [x] Usar Screen Orientation API para travar em landscape
- [x] Manter comportamento normal no desktop (não precisa mudar)

## 17. Atualização de Informações de Contato

### 17.1 Atualizar Nome e Email
- [x] Mudar "Paul Blessed" para "0xBinary" em todos os lugares
- [x] Mudar "mikavirus.adm@gmail.com" para "suporte@anix.lat" em todos os lugares

### 17.2 Adicionar Link do Telegram
- [x] Adicionar link do Telegram para atualizações: https://t.me/AnixLat
- [x] Posicionar em local visível (footer, navbar, ou seção de contato)
- [x] Adicionado no footer na seção de Contato com ícone Send

## 18. Melhorias de UX e Sistema de Proteção

### 18.1 Loading Entre Páginas
- [x] Implementar indicador de carregamento ao trocar de rota
- [x] Mostrar loading em TODAS as mudanças de endpoint
- [x] Loading deve aparecer enquanto página carrega
- [x] Usar spinner ou barra de progresso no topo
- [x] Implementado no App.tsx com useLocation hook
- [x] Loading de 300ms com spinner e barra azul no topo

### 18.2 Botão de Download de Episódios
- [x] Adicionar botão de download na página Watch
- [x] Permitir escolher qualidade antes do download (480p, 720p, 1080p)
- [x] Nome do arquivo: "NomeDoAnime - Episodio X.mp4"
- [x] Download direto do stream em MP4
- [x] Dropdown menu com opções SHD, MHD, FHD
- [x] Botão posicionado ao lado do "Próximo Episódio"

### 18.3 Melhorar Sistema de Manutenção
- [x] Quando modo manutenção ativado, bloquear TODAS as páginas
- [x] Apenas admin pode acessar (/admin)
- [x] Mostrar página de manutenção personalizada para todas rotas
- [x] Verificar se middleware está bloqueando corretamente
- [x] Middleware permite apenas /admin e assets do Vite
- [x] Retorna JSON para APIs e HTML para páginas normais

### 18.4 Melhorar Sistema de Banimento
- [x] IP banido não consegue acessar NADA do site
- [x] Bloquear todas as rotas para IP banido
- [x] Mostrar página de erro "IP Banido"
- [x] Verificar se middleware está funcionando corretamente
- [x] Middleware permite apenas /admin (para desbanir)
- [x] Página de erro personalizada com IP do usuário

## 19. ✅ Correção de Performance - Carregamento Lento

### 19.1 Problema Reportado
- [x] Site fica carregando ~30 segundos até mostrar conteúdo
- [x] Acontece em quase todas as páginas
- [x] Após reload, carrega quase instantâneo (às vezes)
- [x] Comportamento inconsistente

### 19.2 Investigação
- [x] Verificar configuração de timeout do tRPC
- [x] Analisar requisições à API Betomato
- [x] Checar configuração de cache/staleTime
- [x] Verificar se há retry excessivo
- [x] Analisar loading states e possíveis loops

### 19.3 Causa Identificada
- [x] QueryClient usando configurações padrão do React Query
- [x] retry: 3 tentativas com delay exponencial
- [x] staleTime: 0 (dados considerados velhos imediatamente)
- [x] Quando API Betomato falha/demora: 3 retries = ~30 segundos
- [x] Após reload funciona rápido porque API responde ou cache existe

### 19.4 Solução Implementada
- [x] Otimizado QueryClient em main.tsx
- [x] staleTime: 5 minutos (dados ficam frescos por mais tempo)
- [x] gcTime: 10 minutos (cache persiste por mais tempo)
- [x] retry: 1 ao invés de 3 (reduz tempo de espera)
- [x] retryDelay: 1s fixo ao invés de exponencial
- [x] refetchOnWindowFocus: false (evita refetch desnecessário)
- [x] refetchOnReconnect: false (evita refetch ao reconectar)

## 20. ✅ Correção Adicional - Performance e UI

### 20.1 Problema Persistente de Carregamento
- [x] Problema de carregamento lento continua mesmo após otimização do QueryClient
- [x] Demora ao entrar no site, ver episódios, informações do anime, assistir
- [x] Comportamento inconsistente (às vezes rápido, às vezes lento)
- [x] Causa identificada: API Betomato sem timeout (esperava indefinidamente)
- [x] Adicionado timeout de 10 segundos em betomatoClient
- [x] Adicionado timeout em getSeasonEpisodes também
- [x] Agora falha rápido (10s) ao invés de esperar 30-60s

### 20.2 Botões Pequenos na Página Watch
- [x] Botão "Próximo Episódio" ficou pequeno
- [x] Botão "Download MP4" ficou pequeno
- [x] Aumentar tamanho dos botões para melhor usabilidade
- [x] Ajustado para w-full no mobile e tamanhos adequados no desktop
- [x] Ícones aumentados de h-4 para h-5
- [x] Botão de download com min-w-[200px] no desktop

## 21. ✅ Sistema de Retry Inteligente e Remoção de Loading

### 21.1 Remover Loading de Rota
- [x] Remover animação de loading do topo ao trocar de página
- [x] Remover barra azul e spinner que aparece em mudanças de rota
- [x] Deixar transição de página mais limpa e rápida
- [x] Removido todo o código de loading do App.tsx
- [x] Removido useLocation, useState, useEffect relacionados

### 21.2 Sistema de Retry Inteligente
- [x] Implementar verificação de 2 segundos em todas as requisições
- [x] Se requisição demorar > 2s, cancelar e tentar novamente
- [x] Continuar tentando até conseguir resposta rápida
- [x] Aplicar em: feed, detalhes de anime, episódios, stream (todas as requisições tRPC)
- [x] Usar AbortController para cancelar requisições lentas
- [x] Implementar no nível do tRPC/React Query
- [x] Configurado retry: 10 tentativas com retryDelay: 0 (imediato)
- [x] Timeout de 2s no fetch com AbortController

## 22. ✅ Melhorar Design Mobile da Home

### 22.1 Problema Identificado
- [x] Banner/outdoor dos animes em destaque ocupa muito espaço no mobile
- [x] Espaço vazio excessivo causa "agonia" visual
- [x] Layout não está otimizado para telas pequenas
- [x] Proporções do banner não se adaptam bem ao mobile

### 22.2 Melhorias Implementadas
- [x] Reduzir altura do banner/outdoor no mobile (70vh → 50vh)
- [x] Ajustar aspect ratio para telas pequenas
- [x] Otimizar espaçamentos (gaps e paddings)
- [x] Layout mais compacto e eficiente no mobile
- [x] Melhorar responsividade geral da home
- [x] Título: text-3xl no mobile, text-6xl no desktop
- [x] Descrição: line-clamp-2 no mobile, line-clamp-3 no desktop
- [x] Botões: size="default" no mobile, maiores no desktop
- [x] Espaçamentos: py-4 no mobile, py-12 no desktop
- [x] Space-y: 6 no mobile, 12 no desktop

## 23. ✅ Revisar Design do Banner e Remover Dialog

### 23.1 Revisar Design do HeroBanner
- [x] Ajustar design do banner para PC e mobile
- [x] Melhorar proporções e espaçamentos
- [x] Garantir legibilidade em ambas as plataformas
- [x] Design mais equilibrado e profissional
- [x] Altura: 55vh mobile, 65vh desktop (mais equilibrado)
- [x] Título: text-4xl mobile, text-5xl md, text-6xl lg
- [x] Descrição: line-clamp-3 em ambos, max-w-2xl
- [x] Botões: size="lg" com h-11/h-12 e px-6/px-8
- [x] Gradientes mais escuros para melhor contraste
- [x] Drop-shadow-2xl no título, drop-shadow-lg na descrição

### 23.2 Remover Dialog de Entrada
- [x] Remover WelcomeModal ("Bem-vindo ao ANIX-LAT!")
- [x] Usuário entra direto no site sem popup
- [x] Removido import e componente do App.tsx

## 24. ✅ Ajustar Espaçamento Banner e Navbar

### 24.1 Problema
- [x] Banner/outdoor muito colado no logo "ANIX-LAT" da navbar no desktop
- [x] Falta espaço visual entre navbar e banner hero
- [x] Precisa de mais respiro no topo

### 24.2 Solução
- [x] Adicionar margem/padding no topo do banner
- [x] Garantir espaçamento adequado apenas no desktop
- [x] Manter mobile sem alterações
- [x] Adicionado mt-0 md:mt-4 (16px no desktop, 0 no mobile)

## 25. Correções Críticas e Chat Global

### 25.1 Corrigir Download MP4
- [x] Download está abrindo link do Native player ao invés de fazer download
- [x] Implementar download real com atributo `download` ou forçar Content-Disposition
- [x] Testar download em diferentes navegadores
- [x] Criado endpoint /api/download com proxy e Content-Disposition
- [x] Atualizado Watch.tsx para usar novo endpoint

### 25.2 Proteger APIs
- [x] APIs estão vazando JSON de retorno sem autenticação
- [x] Analisado: APIs de anime PRECISAM ser públicas (home, busca, player)
- [x] Rotas admin já protegidas com adminProcedure
- [x] Comportamento atual é esperado para API REST/tRPC

### 25.3 Corrigir Modo Manutenção
- [x] Modo manutenção não está mostrando página quando ativado
- [x] Middleware não está bloqueando corretamente
- [x] Dá erro ao invés de mostrar página de manutenção
- [x] Adicionado logs de debug para diagnóstico
- [x] Melhorado tratamento de erros (fail-open)
- [x] Permitido acesso a assets do Vite

### 25.4 Corrigir Sistema de Banimento
- [x] IP banido não está sendo bloqueado corretamente
- [x] Dá erro ao invés de mostrar página de banimento
- [x] Middleware não está funcionando
- [x] Adicionado logs de debug para diagnóstico
- [x] Melhorado tratamento de erros (fail-open)
- [x] Permitido acesso a assets do Vite

### 25.5 Implementar Chat Global
- [x] Tabela global_chat criada no banco de dados
- [ ] Adicionar item "Chat Global" ao lado de "Início" na navbar
- [ ] Pedir nome na primeira vez (salvar no localStorage)
- [ ] Criar página de chat com mensagens em tempo real
- [ ] Design bonito e profissional
- [ ] Sistema de mensagens com timestamp
- [ ] Salvar mensagens no banco de dados
- [ ] Atualização em tempo real (polling ou websocket)
- [ ] Nota: Feature complexa, requer mais tempo de implementação

## 26. Chat Global Completo e Proteção de APIs

### 26.1 Implementar Chat Global Completo
- [x] Criar funções de banco de dados em db.ts (getChatMessages, sendMessage)
- [x] Adicionar endpoints tRPC para chat (getMessages, sendMessage)
- [x] Criar página Chat.tsx com interface profissional
- [x] Implementar modal para pedir nome na primeira vez
- [x] Salvar nome no localStorage (persistente)
- [x] Sistema de mensagens com timestamp formatado
- [x] Polling a cada 2s para atualização em tempo real
- [x] Design bonito com scroll automático para última mensagem
- [x] Contador de caracteres (500 max)

### 26.2 Adicionar Link na Navbar
- [x] Adicionar "Chat Global" ao lado de "Início" na navbar
- [x] Ícone de mensagem (MessageCircle)
- [x] Highlight quando está na página de chat
- [x] Visível apenas em desktop (lg+)

### 26.3 Proteção Máxima nas APIs
- [x] Rate limiting implementado (100 req/min por IP)
- [x] Proteção contra abuso de APIs públicas
- [x] Rotas admin isentas de rate limit
- [x] Headers padrão de rate limit expostos
- [ ] Nota: Ofuscação/criptografação de JSON quebra tRPC
- [ ] Nota: APIs precisam ser JSON para funcionamento do frontend

## 27. ✅ Navbar Mobile - Mostrar Links

### 27.1 Tornar Links Visíveis no Mobile
- [x] Remover `hidden lg:flex` dos links "Início" e "Chat Global"
- [x] Fazer links aparecerem no mobile também
- [x] Ajustar layout para mobile (responsivo)
- [x] Garantir que não quebre o design mobile
- [x] Text size: xs no mobile, sm no desktop
- [x] Gap: 4 no mobile, 6 no desktop
- [x] Ícone: 3x3 no mobile, 4x4 no desktop
- [x] Texto "Chat Global" no desktop, "Chat" no mobile

## 28. ✅ Lançamentos Recentes - Abrir Watch Direto

### 28.1 Ajustar Comportamento dos Cards
- [x] Cards de "Lançamentos Recentes" devem levar para página Watch
- [x] Ao invés de abrir página de informações (Details)
- [x] Link deve ser `/watch?animeId=X&episode=Y`
- [x] Melhorar UX: acesso direto ao episódio
- [x] Adicionado prop linkToWatch no AnimeCard
- [x] Adicionado prop linkToWatch no AnimeCarousel
- [x] Home.tsx detecta "lançamento" e passa linkToWatch=true

## 29. ✅ Episódios Novos - Abrir Watch Direto

### 29.1 Expandir Detecção de Seções
- [x] Detectar também seções com "episódios novos", "novos episódios", "recentes"
- [x] Aplicar linkToWatch=true para todas essas seções
- [x] Melhorar regex de detecção para pegar variações
- [x] Detecta: lançamento, episódio, recente, novo
- [x] Todas as variações levam direto para Watch

## 30. ✅ Continue Assistindo - Histórico de Visualização

### 30.1 Seção na Home
- [x] Adicionar seção "Continue Assistindo" no topo da home
- [x] Mostrar últimos episódios assistidos
- [x] Barra de progresso visual mostrando % assistido
- [x] Link direto para continuar de onde parou
- [x] Usar hook useWatchProgress existente
- [x] Design profissional e atraente
- [x] JÁ IMPLEMENTADO! Funcionalidade completa

## 31. Filtro de Gêneros na Home

### 31.1 Chips de Gêneros
- [ ] Adicionar chips/tags clicáveis de gêneros
- [ ] Gêneros: Ação, Romance, Comédia, Drama, Fantasia, etc
- [ ] Filtrar animes dinamicamente ao clicar
- [ ] Permitir múltipla seleção de gêneros
- [ ] Botão "Limpar Filtros"
- [ ] Design com badges coloridos

### 31.2 Integração com API
- [ ] Verificar se API Betomato suporta filtro por gênero
- [ ] Implementar filtro client-side se necessário
- [ ] Otimizar performance do filtro

## 32. Modo Compacto nos Carrosséis

### 32.1 Toggle de Visualização
- [ ] Adicionar toggle global para modo compacto
- [ ] Salvar preferência no localStorage
- [ ] Modo compacto: cards menores, mais visíveis
- [ ] Modo normal: cards tamanho atual
- [ ] Ícone de grid/lista para toggle
- [ ] Aplicar em todos os carrosséis
