import { Search, X, Bell, User } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { useState, useEffect } from "react";
import { trpc } from "../lib/trpc";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Badge } from "./ui/badge";
import { MessageCircle } from "lucide-react";

export default function Navbar() {
  const [location, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [showMobileSearch, setShowMobileSearch] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Buscar notificações
  const { data: notifications } = trpc.public.getNotifications.useQuery();
  const unreadCount = notifications?.length || 0;

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Sincronizar input com URL quando estiver na página de pesquisa
  useEffect(() => {
    if (location.startsWith("/search")) {
      const searchParams = new URLSearchParams(window.location.search);
      const q = searchParams.get("q") || "";
      setSearchQuery(q);
    } else {
      setSearchQuery("");
    }
  }, [location]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Forçar navegação completa para garantir atualização
      const newUrl = `/search?q=${encodeURIComponent(searchQuery)}`;
      if (location.startsWith("/search")) {
        // Se já está na página de busca, forçar reload
        window.location.href = newUrl;
      } else {
        setLocation(newUrl);
      }
      setShowMobileSearch(false);
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "success":
        return "text-green-500";
      case "warning":
        return "text-yellow-500";
      case "error":
        return "text-blue-500";
      default:
        return "text-blue-500";
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-black" : "bg-gradient-to-b from-black via-black/80 to-transparent"
      }`}
    >
      <div className="px-4 md:px-8 lg:px-12 flex items-center justify-between h-16 md:h-20">
        {/* Logo and Navigation */}
        <div className="flex items-center gap-6 md:gap-8">
          <Link href="/">
            <span className="text-2xl md:text-3xl font-bold text-primary hover:text-primary/90 transition cursor-pointer tracking-tight">
              Mdz Plus
            </span>
          </Link>
          <div className="flex items-center gap-4 md:gap-6">
            <Link href="/">
              <span
                className={`text-xs md:text-sm font-medium transition cursor-pointer ${
                  location === "/" ? "text-white" : "text-white/70 hover:text-white"
                }`}
              >
                Início
              </span>
            </Link>
            <Link href="/chat">
              <span
                className={`text-xs md:text-sm font-medium transition cursor-pointer flex items-center gap-1 md:gap-2 ${
                  location === "/chat" ? "text-white" : "text-white/70 hover:text-white"
                }`}
              >
                <MessageCircle className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Chat Global</span>
                <span className="sm:hidden">Chat</span>
              </span>
            </Link>
          </div>
        </div>

        {/* Right Side Actions */}
        <div className="flex items-center gap-2 md:gap-4">
          {/* Desktop Search */}
          <form onSubmit={handleSearch} className="hidden md:block">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/60 group-focus-within:text-white transition" />
              <Input
                type="text"
                placeholder="Títulos, gêneros..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 w-0 md:w-56 lg:w-64 bg-black/40 border border-white/20 text-white placeholder:text-white/50 focus:bg-black/60 focus:border-white/40 focus:w-64 lg:focus:w-80 transition-all duration-300 rounded-sm h-9"
              />
            </div>
          </form>

          {/* Mobile Search Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-white hover:bg-white/10 h-9 w-9"
            onClick={() => setShowMobileSearch(!showMobileSearch)}
          >
            {showMobileSearch ? <X className="h-5 w-5" /> : <Search className="h-5 w-5" />}
          </Button>

          {/* Notifications Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/10 h-9 w-9 relative"
              >
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <Badge
                    variant="destructive"
                    className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                  >
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </Badge>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="end"
              className="w-80 bg-zinc-900 border-zinc-800 text-white max-h-96 overflow-y-auto"
            >
              {notifications && notifications.length > 0 ? (
                notifications.map((notif) => (
                  <DropdownMenuItem
                    key={notif.id}
                    className="flex flex-col items-start p-4 focus:bg-zinc-800 cursor-default"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Bell className={`h-4 w-4 ${getNotificationColor(notif.type)}`} />
                      <span className="font-medium text-sm">{notif.title}</span>
                    </div>
                    <p className="text-sm text-zinc-400">{notif.message}</p>
                    <p className="text-xs text-zinc-500 mt-1">
                      {new Date(notif.createdAt).toLocaleString("pt-BR")}
                    </p>
                  </DropdownMenuItem>
                ))
              ) : (
                <DropdownMenuItem className="p-4 text-center text-zinc-500 cursor-default">
                  Nenhuma notificação
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User Profile */}
          <Link href="/profile">
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/10 h-9 w-9"
            >
              <User className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>

      {/* Mobile Search Dropdown */}
      {showMobileSearch && (
        <div className="md:hidden bg-black border-t border-white/10 p-4 animate-in slide-in-from-top-2 duration-200">
          <form onSubmit={handleSearch}>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/60" />
              <Input
                type="text"
                placeholder="Buscar animes, gêneros..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-full bg-white/10 border border-white/20 text-white placeholder:text-white/50 focus:bg-white/15 focus:border-white/40 rounded-sm"
                autoFocus
              />
            </div>
          </form>
        </div>
      )}
    </nav>
  );
}
