import { useState } from "react";
import { Mail, Heart, Send } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export default function Footer() {
  return (
    <footer className="bg-black/95 border-t border-white/10 mt-auto">
      <div className="container py-8 md:py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold text-primary">Mdz PLUS</h3>
            <p className="text-sm text-foreground/70 leading-relaxed">
              Sua plataforma de streaming de animes com qualidade profissional.
              Assista aos seus animes favoritos com legendas e dublagens em português.
            </p>
          </div>

          {/* Contact */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold">Contato</h3>
            <div className="flex flex-col gap-2">
              <a
                href="https://t.me/gringomdz"
                className="flex items-center gap-2 text-sm text-foreground/70 hover:text-primary transition"
              >
                <Send className="h-4 w-4" />
                Telegram: @gringomdz
              </a>
              <a
                href="https://t.me/mdzm0dders"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-foreground/70 hover:text-primary transition"
              >
                <Send className="h-4 w-4" />
                Atualizações no Telegram
              </a>
            </div>
          </div>

          {/* Legal */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold">Legal</h3>
            <div className="flex flex-col gap-2">
              <Dialog>
                <DialogTrigger asChild>
                  <button className="text-sm text-foreground/70 hover:text-primary transition text-left">
                    Termos de Uso
                  </button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Termos de Uso</DialogTitle>
                    <DialogDescription className="text-left space-y-4 pt-4">
                      <div>
                        <h4 className="font-semibold text-foreground mb-2">1. Aceitação dos Termos</h4>
                        <p className="text-sm">
                          Ao acessar e usar o Mdz Plus, você concorda com estes termos de uso.
                          Se você não concorda com qualquer parte destes termos, não deve usar este site.
                        </p>
                      </div>

                      <div>
                        <h4 className="font-semibold text-foreground mb-2">2. Uso do Serviço</h4>
                        <p className="text-sm">
                          O Mdz Plus é uma plataforma de streaming de animes. Você concorda em usar
                          o serviço apenas para fins pessoais e não comerciais. É proibido copiar,
                          distribuir ou modificar qualquer conteúdo do site sem autorização.
                        </p>
                      </div>

                      <div>
                        <h4 className="font-semibold text-foreground mb-2">3. Dados Locais</h4>
                        <p className="text-sm">
                          Todos os dados (favoritos, histórico) são armazenados localmente no seu
                          navegador. Não coletamos ou armazenamos informações pessoais em nossos servidores.
                        </p>
                      </div>

                      <div>
                        <h4 className="font-semibold text-foreground mb-2">4. Modificações</h4>
                        <p className="text-sm">
                          Reservamos o direito de modificar estes termos a qualquer momento.
                          Mudanças entram em vigor imediatamente após publicação.
                        </p>
                      </div>
                    </DialogDescription>
                  </DialogHeader>
                </DialogContent>
              </Dialog>

              <Dialog>
                <DialogTrigger asChild>
                  <button className="text-sm text-foreground/70 hover:text-primary transition text-left">
                    Aviso Legal
                  </button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Aviso Legal</DialogTitle>
                    <DialogDescription className="text-left space-y-4 pt-4">
                      <div>
                        <h4 className="font-semibold text-foreground mb-2">⚠️ Isenção de Responsabilidade</h4>
                        <p className="text-sm">
                          O Mdz Plus é uma plataforma de agregação de conteúdo. Não hospedamos nenhum
                          arquivo de vídeo em nossos servidores. Todo o conteúdo é fornecido por fontes
                          externas de terceiros.
                        </p>
                      </div>

                      <div>
                        <h4 className="font-semibold text-foreground mb-2">📺 Direitos Autorais</h4>
                        <p className="text-sm">
                          Todos os animes, imagens e marcas pertencem aos seus respectivos proprietários.
                          Se você é proprietário de direitos autorais e acredita que seu conteúdo está
                          sendo usado indevidamente, entre em contato conosco.
                        </p>
                      </div>

                      <div>
                        <h4 className="font-semibold text-foreground mb-2">🔒 Uso por Sua Conta e Risco</h4>
                        <p className="text-sm">
                          O uso deste site é por sua conta e risco. Não nos responsabilizamos por
                          qualquer dano, perda de dados ou problemas decorrentes do uso do serviço.
                        </p>
                      </div>

                      <div>
                        <h4 className="font-semibold text-foreground mb-2">🌐 Links Externos</h4>
                        <p className="text-sm">
                          Este site pode conter links para sites externos. Não somos responsáveis
                          pelo conteúdo ou práticas de privacidade desses sites.
                        </p>
                      </div>
                    </DialogDescription>
                  </DialogHeader>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-6 border-t border-white/10 text-center">
          <p className="text-sm text-foreground/60 flex items-center justify-center gap-2">
            © 2026 John Mdz & Paul Blessed. Feito com <Heart className="h-4 w-4 text-primary fill-current" /> para a comunidade de anime.
          </p>
        </div>
      </div>
    </footer>
  );
}
