import { useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import { Play, Pause, Volume2, VolumeX, Maximize, Settings, SkipForward, Rewind, FastForward, Loader2 } from "lucide-react";
import { Button } from "./ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";

interface VideoPlayerProps {
  streamUrl: string;
  qualities?: {
    shd?: string | null;
    mhd?: string | null;
    fhd?: string | null;
  };
  onTimeUpdate?: (currentTime: number, duration: number) => void;
  onEnded?: () => void;
  initialTime?: number;
  onNextEpisode?: () => void;
  hasNextEpisode?: boolean;
}

const PLAYBACK_RATES = [0.5, 0.75, 1, 1.25, 1.5, 2];

export default function VideoPlayer({
  streamUrl,
  qualities,
  onTimeUpdate,
  onEnded,
  initialTime = 0,
  onNextEpisode,
  hasNextEpisode,
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const progressBarRef = useRef<HTMLInputElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [selectedQuality, setSelectedQuality] = useState<string>("auto");
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [hoverPosition, setHoverPosition] = useState(0);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | undefined>(undefined);
  const initialTimeAppliedRef = useRef(false);

  // Initialize HLS
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    setIsLoading(true);
    initialTimeAppliedRef.current = false;

    if (Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: false,
        maxBufferLength: 30,
        maxMaxBufferLength: 60,
      });
      hlsRef.current = hls;

      hls.loadSource(streamUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setIsLoading(false);
        
        // Aplicar initialTime apenas UMA VEZ
        if (initialTime > 0 && !initialTimeAppliedRef.current) {
          initialTimeAppliedRef.current = true;
          video.currentTime = initialTime;
        }
        
        // Autoplay
        video.play().catch(err => {
          console.log("Autoplay blocked:", err);
          setIsLoading(false);
        });
      });

      hls.on(Hls.Events.ERROR, (event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            default:
              hls.destroy();
              break;
          }
        }
      });
    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = streamUrl;
      video.addEventListener("loadedmetadata", () => {
        setIsLoading(false);
        
        if (initialTime > 0 && !initialTimeAppliedRef.current) {
          initialTimeAppliedRef.current = true;
          video.currentTime = initialTime;
        }
        
        video.play().catch(err => {
          console.log("Autoplay blocked:", err);
        });
      });
    }

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [streamUrl]); // initialTime aplicado apenas UMA VEZ no MANIFEST_PARSED

  // Video event listeners
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => {
      const time = video.currentTime;
      setCurrentTime(time);
      
      // Callback passivo (não modifica player)
      if (onTimeUpdate && video.duration) {
        onTimeUpdate(time, video.duration);
      }
    };

    const handleLoadedMetadata = () => {
      setDuration(video.duration);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      if (onEnded) {
        onEnded();
      }
    };

    const handlePlay = () => {
      setIsPlaying(true);
    };

    const handlePause = () => {
      setIsPlaying(false);
    };

    const handleWaiting = () => {
      setIsLoading(true);
    };

    const handleCanPlay = () => {
      setIsLoading(false);
    };

    video.addEventListener("timeupdate", handleTimeUpdate);
    video.addEventListener("loadedmetadata", handleLoadedMetadata);
    video.addEventListener("ended", handleEnded);
    video.addEventListener("play", handlePlay);
    video.addEventListener("pause", handlePause);
    video.addEventListener("waiting", handleWaiting);
    video.addEventListener("canplay", handleCanPlay);

    return () => {
      video.removeEventListener("timeupdate", handleTimeUpdate);
      video.removeEventListener("loadedmetadata", handleLoadedMetadata);
      video.removeEventListener("ended", handleEnded);
      video.removeEventListener("play", handlePlay);
      video.removeEventListener("pause", handlePause);
      video.removeEventListener("waiting", handleWaiting);
      video.removeEventListener("canplay", handleCanPlay);
    };
  }, [onTimeUpdate, onEnded]);

  // Auto-hide controles
  useEffect(() => {
    if (!showControls || !isPlaying) return;

    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }

    controlsTimeoutRef.current = setTimeout(() => {
      setShowControls(false);
    }, 3000);

    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
    };
  }, [showControls, isPlaying]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;

    if (video.paused) {
      video.play().catch(err => console.error("Play error:", err));
    } else {
      video.pause();
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = !video.muted;
    setIsMuted(video.muted);
  };

  const toggleFullscreen = async () => {
    const container = containerRef.current;
    if (!container) return;

    if (!document.fullscreenElement) {
      await container.requestFullscreen();
      
      // Forçar orientação horizontal no mobile
      if (/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)) {
        try {
          // @ts-ignore - Screen Orientation API pode não estar em todos os tipos
          if (screen.orientation && screen.orientation.lock) {
            // @ts-ignore
            await screen.orientation.lock('landscape').catch(() => {});
          }
        } catch (err) {
          // Ignorar erro se API não disponível
        }
      }
    } else {
      document.exitFullscreen();
      
      // Desbloquear orientação ao sair do fullscreen
      if (/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)) {
        try {
          // @ts-ignore
          if (screen.orientation && screen.orientation.unlock) {
            // @ts-ignore
            screen.orientation.unlock();
          }
        } catch (err) {
          // Ignorar erro
        }
      }
    }
  };

  const skip = (seconds: number) => {
    const video = videoRef.current;
    if (!video) return;

    video.currentTime = Math.max(0, Math.min(video.duration, video.currentTime + seconds));
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (!video) return;

    const time = parseFloat(e.target.value);
    video.currentTime = time;
  };

  // Preview seekbar
  const handleProgressHover = (e: React.MouseEvent<HTMLInputElement>) => {
    const progressBar = progressBarRef.current;
    if (!progressBar) return;

    const rect = progressBar.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    const time = pos * duration;
    setHoverTime(time);
    setHoverPosition(e.clientX - rect.left);
  };

  const handleProgressLeave = () => {
    setHoverTime(null);
  };

  // Playback rate
  const changePlaybackRate = (rate: number) => {
    const video = videoRef.current;
    if (!video) return;

    video.playbackRate = rate;
    setPlaybackRate(rate);
    setShowSpeedMenu(false);
  };

  const formatTime = (time: number) => {
    if (!isFinite(time)) return "0:00";
    
    const hours = Math.floor(time / 3600);
    const minutes = Math.floor((time % 3600) / 60);
    const seconds = Math.floor(time % 60);

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  const handleMouseMove = () => {
    setShowControls(true);
  };

  // Clicar/tocar no centro apenas toggle controles (NÃO pausa)
  const handleVideoClick = () => {
    setShowControls(prev => !prev);
  };

  // Touch events para mobile
  const handleTouchStart = () => {
    setShowControls(prev => !prev);
  };

  const changeQuality = (quality: string) => {
    setSelectedQuality(quality);
    const video = videoRef.current;
    if (!video || !qualities) return;

    let newUrl = streamUrl;
    if (quality === "480p" && qualities.shd) {
      newUrl = qualities.shd;
    } else if (quality === "720p" && qualities.mhd) {
      newUrl = qualities.mhd;
    } else if (quality === "1080p" && qualities.fhd) {
      newUrl = qualities.fhd;
    }

    const currentTime = video.currentTime;
    const wasPlaying = !video.paused;

    if (hlsRef.current) {
      hlsRef.current.loadSource(newUrl);
      hlsRef.current.once(Hls.Events.MANIFEST_PARSED, () => {
        video.currentTime = currentTime;
        if (wasPlaying) {
          video.play();
        }
      });
    }
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full bg-black aspect-video rounded-lg overflow-hidden shadow-2xl"
      onMouseMove={handleMouseMove}
      onMouseLeave={() => isPlaying && setShowControls(false)}
      style={{ cursor: showControls ? 'default' : 'none' }}
    >
      <video
        ref={videoRef}
        className="w-full h-full"
        onClick={handleVideoClick}
        onTouchStart={handleTouchStart}
        playsInline
      />

      {/* Loading Spinner */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="h-12 w-12 text-primary animate-spin" />
            <p className="text-sm text-white/80 font-medium">Carregando...</p>
          </div>
        </div>
      )}

      {/* Big Play Button (fallback if autoplay blocked) */}
      {!isPlaying && !isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/20 z-10 pointer-events-auto">
          <Button
            onClick={togglePlay}
            size="icon"
            className="h-20 w-20 rounded-full bg-primary/90 hover:bg-primary hover:scale-110 transition-all shadow-2xl backdrop-blur-sm pointer-events-auto"
          >
            <Play className="h-10 w-10 ml-1" fill="currentColor" />
          </Button>
        </div>
      )}

      {/* Controls */}
      <div
        className={`absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/40 transition-opacity duration-300 ${
          showControls || !isPlaying ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
      >
        <div className="absolute bottom-0 left-0 right-0 p-3 md:p-5 space-y-3">
          {/* Progress Bar com Preview */}
          <div className="relative group">
            {/* Hover Tooltip */}
            {hoverTime !== null && (
              <div
                className="absolute bottom-full mb-2 px-2 py-1 bg-black/95 text-white text-xs rounded pointer-events-none whitespace-nowrap"
                style={{ left: `${hoverPosition}px`, transform: 'translateX(-50%)' }}
              >
                {formatTime(hoverTime)}
              </div>
            )}

            <input
              ref={progressBarRef}
              type="range"
              min="0"
              max={duration || 0}
              value={currentTime}
              onChange={handleSeek}
              onMouseMove={handleProgressHover}
              onMouseLeave={handleProgressLeave}
              className="w-full h-1 bg-white/20 rounded-full appearance-none cursor-pointer transition-all
                [&::-webkit-slider-thumb]:appearance-none 
                [&::-webkit-slider-thumb]:w-3 
                [&::-webkit-slider-thumb]:h-3 
                [&::-webkit-slider-thumb]:rounded-full 
                [&::-webkit-slider-thumb]:bg-primary 
                [&::-webkit-slider-thumb]:cursor-pointer 
                [&::-webkit-slider-thumb]:shadow-lg 
                [&::-webkit-slider-thumb]:transition-transform
                [&::-webkit-slider-thumb]:scale-0
                group-hover:[&::-webkit-slider-thumb]:scale-100
                [&::-moz-range-thumb]:w-3 
                [&::-moz-range-thumb]:h-3 
                [&::-moz-range-thumb]:rounded-full 
                [&::-moz-range-thumb]:bg-primary 
                [&::-moz-range-thumb]:border-0
                [&::-moz-range-thumb]:cursor-pointer"
              style={{
                background: `linear-gradient(to right, rgb(59, 130, 246) ${(currentTime / duration) * 100}%, rgba(255,255,255,0.2) ${(currentTime / duration) * 100}%)`
              }}
            />
          </div>

          {/* Controls Row */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={togglePlay}
                className="text-white hover:bg-white/10 h-9 w-9"
              >
                {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => skip(-10)}
                className="text-white hover:bg-white/10 h-8 w-8 md:h-9 md:w-9"
              >
                <Rewind className="h-4 w-4" />
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => skip(10)}
                className="text-white hover:bg-white/10 h-8 w-8 md:h-9 md:w-9"
              >
                <FastForward className="h-4 w-4" />
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={toggleMute}
                className="text-white hover:bg-white/10 h-9 w-9"
              >
                {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
              </Button>

              <span className="text-white text-xs md:text-sm font-medium ml-1 md:ml-2 tabular-nums">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
            </div>

            <div className="flex items-center gap-1">
              {hasNextEpisode && onNextEpisode && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onNextEpisode}
                  className="text-white hover:bg-white/10 gap-1.5 h-8 px-2 md:px-3"
                >
                  <SkipForward className="h-4 w-4" />
                  <span className="hidden sm:inline text-xs">Próximo</span>
                </Button>
              )}

              {/* Velocidade */}
              <div className="relative">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                  className="text-white hover:bg-white/10 gap-1 h-8 px-2"
                >
                  <Settings className="h-3.5 w-3.5" />
                  <span className="text-xs">{playbackRate}x</span>
                </Button>

                {showSpeedMenu && (
                  <div className="absolute bottom-full right-0 mb-2 bg-black/95 backdrop-blur-sm rounded-lg p-2 min-w-[100px] border border-white/10">
                    <div className="text-xs text-zinc-400 mb-2 px-2">Velocidade</div>
                    {PLAYBACK_RATES.map((rate) => (
                      <button
                        key={rate}
                        onClick={() => changePlaybackRate(rate)}
                        className={`w-full text-left px-3 py-2 rounded hover:bg-white/10 transition-colors text-sm ${
                          playbackRate === rate ? 'text-primary font-semibold' : 'text-white'
                        }`}
                      >
                        {rate}x
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {qualities && (
                <Select value={selectedQuality} onValueChange={changeQuality}>
                  <SelectTrigger className="w-16 md:w-20 h-8 bg-transparent border-none text-white text-xs">
                    <Settings className="h-3.5 w-3.5 mr-0.5" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-900/95 backdrop-blur-sm border-zinc-800">
                    <SelectItem value="auto">Auto</SelectItem>
                    {qualities.shd && <SelectItem value="480p">480p</SelectItem>}
                    {qualities.mhd && <SelectItem value="720p">720p</SelectItem>}
                    {qualities.fhd && <SelectItem value="1080p">1080p</SelectItem>}
                  </SelectContent>
                </Select>
              )}

              <Button
                variant="ghost"
                size="icon"
                onClick={toggleFullscreen}
                className="text-white hover:bg-white/10 h-9 w-9"
              >
                <Maximize className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
