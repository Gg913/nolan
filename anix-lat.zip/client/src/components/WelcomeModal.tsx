import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Play, Tv, Heart } from "lucide-react";

export default function WelcomeModal() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    // Check if user has seen welcome modal before
    const hasSeenWelcome = localStorage.getItem("hasSeenWelcome");
    if (!hasSeenWelcome) {
      setOpen(true);
    }
  }, []);

  const handleClose = () => {
    localStorage.setItem("hasSeenWelcome", "true");
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden border-2 border-primary/20">
        <div className="relative bg-gradient-to-br from-primary/20 via-background to-background p-8 md:p-12">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl -z-10" />
          
          <DialogHeader className="space-y-4 text-center">
            <div className="flex justify-center mb-4">
              <div className="p-4 bg-primary/20 rounded-full">
                <Play className="h-12 w-12 text-primary fill-current" />
              </div>
            </div>
            
            <DialogTitle className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Bem-vindo ao Mdz Plus!
            </DialogTitle>
            
            <DialogDescription className="text-base md:text-lg text-foreground/80 leading-relaxed">
              Sua nova plataforma de streaming de animes com qualidade profissional.
              Assista aos seus animes favoritos com legendas e dublagens em português.
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8 mb-8">
            <div className="flex flex-col items-center text-center p-4 bg-card/50 rounded-lg border border-border/50">
              <Play className="h-8 w-8 text-primary mb-3" />
              <h3 className="font-semibold mb-1">Player Profissional</h3>
              <p className="text-sm text-muted-foreground">
                Controles avançados, múltiplas qualidades e atalhos de teclado
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-4 bg-card/50 rounded-lg border border-border/50">
              <Tv className="h-8 w-8 text-primary mb-3" />
              <h3 className="font-semibold mb-1">Catálogo Completo</h3>
              <p className="text-sm text-muted-foreground">
                Milhares de animes organizados por categorias e gêneros
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-4 bg-card/50 rounded-lg border border-border/50">
              <Heart className="h-8 w-8 text-primary mb-3" />
              <h3 className="font-semibold mb-1">Histórico Pessoal</h3>
              <p className="text-sm text-muted-foreground">
                Continue de onde parou em qualquer dispositivo
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <Button
              size="lg"
              onClick={handleClose}
              className="w-full text-lg gap-2 shadow-lg shadow-primary/20"
            >
              <Play className="h-5 w-5" />
              Começar a Assistir
            </Button>
            <span className="block text-center text-sm text-muted-foreground">
              Todos os dados são salvos localmente no seu navegador
            </span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
