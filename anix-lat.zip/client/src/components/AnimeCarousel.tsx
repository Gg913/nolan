import { ChevronLeft, ChevronRight } from "lucide-react";
import { useRef } from "react";
import { Button } from "./ui/button";
import AnimeCard from "./AnimeCard";

interface AnimeItem {
  anime_id?: number;
  thumbnail?: string;
  ep_id?: number;
  ep_anime_id?: number;
  anime_name?: string;
  ep_number?: number;
  dubbed?: boolean;
}

interface AnimeCarouselProps {
  title: string;
  items: AnimeItem[];
  format?: "vertical" | "horizontal";
  linkToWatch?: boolean;
}

export default function AnimeCarousel({ title, items, format = "vertical", linkToWatch = false }: AnimeCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 400;
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  if (!items || items.length === 0) return null;

  return (
    <div className="relative group mb-8 md:mb-12">
      <h2 className="text-lg md:text-xl lg:text-2xl font-semibold mb-3 md:mb-4 text-white px-1">{title}</h2>
      
      <div className="relative -mx-1">
        <Button
          variant="ghost"
          size="icon"
          className="hidden md:flex absolute left-0 top-1/2 -translate-y-1/2 z-10 h-full w-12 bg-black/80 hover:bg-black/90 opacity-0 group-hover:opacity-100 transition-opacity rounded-none items-center justify-center"
          onClick={() => scroll("left")}
        >
          <ChevronLeft className="h-10 w-10 text-white" />
        </Button>

        <div
          ref={scrollRef}
          className="flex gap-2 md:gap-3 overflow-x-auto scrollbar-hide scroll-smooth px-1 py-2"
        >
          {items.map((item, index) => {
            const animeId = item.anime_id || item.ep_anime_id;
            const thumbnail = item.thumbnail;
            
            if (!animeId || !thumbnail) return null;

            return (
              <div key={`${animeId}-${index}`} className="flex-shrink-0">
                <AnimeCard
                  animeId={animeId}
                  thumbnail={thumbnail}
                  title={item.anime_name}
                  episodeNumber={item.ep_number}
                  dubbed={item.dubbed}
                  format={format}
                  linkToWatch={linkToWatch}
                />
              </div>
            );
          })}
        </div>

        <Button
          variant="ghost"
          size="icon"
          className="hidden md:flex absolute right-0 top-1/2 -translate-y-1/2 z-10 h-full w-12 bg-black/80 hover:bg-black/90 opacity-0 group-hover:opacity-100 transition-opacity rounded-none items-center justify-center"
          onClick={() => scroll("right")}
        >
          <ChevronRight className="h-10 w-10 text-white" />
        </Button>
      </div>
    </div>
  );
}
