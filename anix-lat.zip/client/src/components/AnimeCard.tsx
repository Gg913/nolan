import { Link } from "wouter";
import { Play } from "lucide-react";

interface AnimeCardProps {
  animeId: number;
  thumbnail: string;
  title?: string;
  episodeNumber?: number;
  dubbed?: boolean;
  size?: "small" | "medium" | "large";
  format?: "vertical" | "horizontal"; // vertical = 2:3, horizontal = 16:9
  linkToWatch?: boolean; // Se true, vai para /watch ao invés de /anime
}

export default function AnimeCard({
  animeId,
  thumbnail,
  title,
  episodeNumber,
  dubbed,
  size = "medium",
  format = "vertical",
  linkToWatch = false,
}: AnimeCardProps) {
  // Formato vertical (2:3) - padrão
  const verticalSizeClasses = {
    small: "w-28 h-42 md:w-32 md:h-48",
    medium: "w-32 h-48 md:w-40 md:h-60",
    large: "w-40 h-60 md:w-48 md:h-72",
  };
  
  // Formato horizontal (16:9) - para lançamentos e em alta
  const horizontalSizeClasses = {
    small: "w-36 h-20 md:w-44 md:h-24",
    medium: "w-44 h-24 md:w-56 md:h-32 lg:w-64 lg:h-36",
    large: "w-56 h-32 md:w-64 md:h-36",
  };
  
  const sizeClasses = format === "horizontal" ? horizontalSizeClasses : verticalSizeClasses;

  const href = linkToWatch && episodeNumber
    ? `/watch?animeId=${animeId}&episode=${episodeNumber}`
    : `/anime/${animeId}`;

  return (
    <Link href={href}>
      <div className="group block">
        <div
          className={`${sizeClasses[size]} relative rounded-md overflow-hidden bg-card hover-scale cursor-pointer`}
        >
          <img
            src={thumbnail}
            alt={title || `Anime ${animeId}`}
            className="w-full h-full object-cover object-center"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/60 transition-all duration-300 flex items-center justify-center">
            <Play className="h-12 w-12 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>
          {dubbed && (
            <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
              DUB
            </div>
          )}
          {episodeNumber && (
            <div className="absolute bottom-0 left-0 right-0 gradient-overlay p-2">
              <p className="text-xs text-white text-shadow">EP {episodeNumber}</p>
            </div>
          )}
        </div>
        {title && (
          <p className="mt-2 text-sm text-foreground/80 line-clamp-2">{title}</p>
        )}
      </div>
    </Link>
  );
}
