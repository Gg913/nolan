import { Play, Info } from "lucide-react";
import { Link } from "wouter";
import { Button } from "./ui/button";

interface HeroBannerProps {
  animeId: number;
  title: string;
  description: string;
  banner: string;
  tags?: string;
  year?: string;
  rating?: string;
  episodeId?: number;
}

export default function HeroBanner({
  animeId,
  title,
  description,
  banner,
  tags,
  year,
  rating,
  episodeId,
}: HeroBannerProps) {
  return (
    <div className="relative h-[55vh] md:h-[65vh] w-full overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={banner}
          alt={title}
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
      </div>

      <div className="relative container h-full flex items-center">
        <div className="max-w-3xl space-y-3 md:space-y-5">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white drop-shadow-2xl leading-tight">
            {title}
          </h1>
          
          <div className="flex items-center gap-3 md:gap-4 text-sm md:text-base text-white/90 flex-wrap">
            {year && <span className="font-medium">{year}</span>}
            {rating && (
              <>
                <span>•</span>
                <span className="border border-white/60 px-2 py-1 rounded font-medium">
                  {rating}
                </span>
              </>
            )}
            {tags && (
              <>
                <span>•</span>
                <span className="line-clamp-1">{tags}</span>
              </>
            )}
          </div>

          <p className="text-base md:text-lg text-white/90 line-clamp-3 md:line-clamp-3 drop-shadow-lg max-w-2xl">
            {description}
          </p>

          <div className="flex gap-3 pt-2">
            {episodeId ? (
              <Button asChild size="lg" className="gap-2 h-11 md:h-12 px-6 md:px-8 text-base">
                <Link href={`/watch/${episodeId}`}>
                  <Play className="h-5 w-5" />
                  Assistir
                </Link>
              </Button>
            ) : (
              <Button asChild size="lg" variant="secondary" className="gap-2 h-11 md:h-12 px-6 md:px-8 text-base">
                <Link href={`/anime/${animeId}`}>
                  <Info className="h-5 w-5" />
                  Mais Informações
                </Link>
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
