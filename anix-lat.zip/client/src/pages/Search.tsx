import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import AnimeCard from "@/components/AnimeCard";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Loader2, Search as SearchIcon } from "lucide-react";
import { useEffect, useState } from "react";

export default function Search() {
  const [location] = useLocation();
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [page, setPage] = useState(0);
  const [allResults, setAllResults] = useState<any[]>([]);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const q = searchParams.get("q") || "";
    setQuery(q);
    setDebouncedQuery(q);
    setPage(0);
    setAllResults([]);
    setHasMore(true);
  }, [location]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(query);
      setPage(0);
      setAllResults([]);
      setHasMore(true);
    }, 300);

    return () => clearTimeout(timer);
  }, [query]);

  const { data: searchResults, isLoading, isFetching } = trpc.anime.search.useQuery(
    { query: debouncedQuery, page },
    { enabled: debouncedQuery.length > 0 }
  );

  // Acumular resultados quando nova página carregar
  useEffect(() => {
    if (searchResults?.result) {
      if (page === 0) {
        // Primeira página: substituir
        setAllResults(searchResults.result);
      } else {
        // Páginas seguintes: acumular
        setAllResults((prev) => [...prev, ...searchResults.result]);
      }

      // Verificar se tem mais resultados (se retornou menos que 20, não tem mais)
      if (searchResults.result.length < 20) {
        setHasMore(false);
      }
    }
  }, [searchResults, page]);

  const loadMore = () => {
    setPage((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container py-24">
        <h1 className="text-3xl font-bold mb-8">
          Resultados para: <span className="text-primary">{query}</span>
        </h1>

        {isLoading && page === 0 ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : allResults.length > 0 ? (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {allResults.map((anime: any, index: number) => (
                <AnimeCard
                  key={`${anime.id}-${index}`}
                  animeId={anime.id}
                  thumbnail={anime.image}
                  title={anime.name}
                />
              ))}
            </div>

            {/* Botão Mostrar Mais */}
            {hasMore && (
              <div className="flex justify-center mt-8">
                <Button
                  onClick={loadMore}
                  disabled={isFetching}
                  variant="outline"
                  size="lg"
                  className="min-w-[200px]"
                >
                  {isFetching ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Carregando...
                    </>
                  ) : (
                    "Mostrar mais animes"
                  )}
                </Button>
              </div>
            )}
          </>
        ) : debouncedQuery.length > 0 ? (
          <div className="text-center py-20">
            <SearchIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-xl text-foreground/80">
              Nenhum resultado encontrado para "{query}"
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Tente usar palavras-chave diferentes ou verifique a ortografia
            </p>
          </div>
        ) : null}
      </div>
      <Footer />
    </div>
  );
}
