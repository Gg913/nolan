import { useState, useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Send, Image as ImageIcon, Music, Settings, User, X, Upload, Loader2 } from "lucide-react";

interface ChatProfile {
  username: string;
  avatar?: string;
}

interface ChatMessage {
  id: number;
  username: string;
  message?: string;
  userAvatar?: string;
  mediaType?: string;
  mediaUrl?: string;
  timestamp: number;
}

export default function Chat() {
  const [profile, setProfile] = useState<ChatProfile | null>(null);
  const [showSetupModal, setShowSetupModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [tempUsername, setTempUsername] = useState("");
  const [tempAvatarFile, setTempAvatarFile] = useState<File | null>(null);
  const [tempAvatarPreview, setTempAvatarPreview] = useState<string>("");
  const [inputMessage, setInputMessage] = useState("");
  const [selectedMedia, setSelectedMedia] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string>("");
  const [mediaType, setMediaType] = useState<'image' | 'gif' | 'audio' | null>(null);
  const [uploading, setUploading] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  const { data: chatMessages, refetch } = trpc.chat.getMessages.useQuery({ limit: 100 });
  const sendMessageMutation = trpc.chat.sendMessage.useMutation();

  // Load profile from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("chatProfile");
    if (saved) {
      try {
        setProfile(JSON.parse(saved));
      } catch {
        setShowSetupModal(true);
      }
    } else {
      setShowSetupModal(true);
    }
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  // Polling for new messages
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
    }, 2000);
    return () => clearInterval(interval);
  }, [refetch]);

  const uploadToS3 = async (file: File): Promise<string> => {
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error('Upload failed');
      const data = await response.json();
      return data.url;
    } catch (error) {
      console.error('Upload error:', error);
      throw error;
    }
  };

  const saveProfile = async () => {
    if (!tempUsername.trim()) {
      alert("Por favor, insira um nome");
      return;
    }

    setUploading(true);
    try {
      let avatarUrl = tempAvatarPreview;

      if (tempAvatarFile && !tempAvatarPreview.startsWith('http')) {
        avatarUrl = await uploadToS3(tempAvatarFile);
      }

      const newProfile: ChatProfile = {
        username: tempUsername.trim(),
        avatar: avatarUrl || undefined,
      };

      setProfile(newProfile);
      localStorage.setItem("chatProfile", JSON.stringify(newProfile));
      setShowSetupModal(false);
      setShowProfileModal(false);
      setTempUsername("");
      setTempAvatarFile(null);
      setTempAvatarPreview("");
    } catch (error) {
      console.error("Erro ao salvar perfil:", error);
      alert("Erro ao salvar perfil. Tente novamente.");
    } finally {
      setUploading(false);
    }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("Arquivo muito grande! Máximo 5MB");
        return;
      }
      setTempAvatarFile(file);
      setTempAvatarPreview(URL.createObjectURL(file));
    }
  };

  const handleMediaSelect = async (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'audio') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const maxSize = type === 'image' ? 5 * 1024 * 1024 : 10 * 1024 * 1024;
    if (file.size > maxSize) {
      alert(`Arquivo muito grande! Máximo ${maxSize / 1024 / 1024}MB`);
      return;
    }

    setSelectedMedia(file);
    setMediaPreview(URL.createObjectURL(file));
    setMediaType(file.type.includes('gif') ? 'gif' : type);
  };

  const clearMedia = () => {
    setSelectedMedia(null);
    setMediaPreview("");
    setMediaType(null);
  };

  const sendMessage = async () => {
    if (!profile) return;
    if (!inputMessage.trim() && !selectedMedia) return;

    setUploading(true);
    try {
      let mediaUrl = "";
      let finalMediaType = "text";

      if (selectedMedia && mediaType) {
        mediaUrl = await uploadToS3(selectedMedia);
        finalMediaType = mediaType;
      }

      await sendMessageMutation.mutateAsync({
        username: profile.username,
        message: inputMessage.trim() || undefined,
        userAvatar: profile.avatar ?? undefined,
        mediaType: finalMediaType as any,
        mediaUrl: mediaUrl || undefined,
      });

      setInputMessage("");
      clearMedia();
      refetch();
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error);
      alert("Erro ao enviar mensagem");
    } finally {
      setUploading(false);
    }
  };

  const openProfileModal = () => {
    if (profile) {
      setTempUsername(profile.username);
      setTempAvatarPreview(profile.avatar ?? "");
    }
    setShowProfileModal(true);
  };

  const renderMessage = (msg: ChatMessage) => {
    const isOwnMessage = msg.username === profile?.username;

    return (
      <div key={msg.id} className={`flex gap-3 mb-4 ${isOwnMessage ? 'flex-row-reverse' : 'flex-row'}`}>
        {/* Avatar */}
        <div className="flex-shrink-0 mt-1">
          {msg.userAvatar ? (
            <img src={msg.userAvatar} alt={msg.username} className="w-8 h-8 rounded-full object-cover ring-2 ring-background" />
          ) : (
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center ring-2 ring-background">
              <User className="w-4 h-4 text-white" />
            </div>
          )}
        </div>

        {/* Message Content */}
        <div className={`max-w-[70%] flex flex-col ${isOwnMessage ? 'items-end' : 'items-start'} gap-1`}>
          {!isOwnMessage && (
            <span className="text-xs font-semibold text-foreground px-3">{msg.username}</span>
          )}
          
          <div className={`rounded-2xl px-4 py-2.5 break-words ${
            isOwnMessage 
              ? 'bg-primary text-primary-foreground rounded-tr-none shadow-lg' 
              : 'bg-muted rounded-tl-none'
          }`}>
            {/* Media Content */}
            {msg.mediaType === 'image' || msg.mediaType === 'gif' ? (
              <img 
                src={msg.mediaUrl} 
                alt="Imagem" 
                className="max-w-full rounded-xl mb-2 max-h-64 object-cover"
              />
            ) : msg.mediaType === 'audio' ? (
              <audio controls className="max-w-full mb-2 h-8">
                <source src={msg.mediaUrl} />
              </audio>
            ) : null}

            {/* Text Content */}
            {msg.message && (
              <p className="text-sm whitespace-pre-wrap">{msg.message}</p>
            )}
          </div>

          <span className="text-[11px] text-muted-foreground px-3 mt-0.5">
            {new Date(msg.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b bg-card sticky top-0 z-10">
        <div className="container max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Chat Global</h1>
            <p className="text-sm text-muted-foreground">Converse com a comunidade ANIX-LAT</p>
          </div>
          <Button variant="ghost" size="icon" onClick={openProfileModal} className="rounded-full">
            <Settings className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto">
        <div className="container max-w-4xl mx-auto px-4 py-6">
          {!chatMessages || chatMessages.length === 0 ? (
            <div className="text-center text-muted-foreground py-12">
              <div className="inline-block p-4 rounded-full bg-muted mb-4">
                <User className="h-8 w-8" />
              </div>
              <p className="text-lg font-medium">Nenhuma mensagem ainda</p>
              <p className="text-sm">Seja o primeiro a conversar!</p>
            </div>
          ) : (
            chatMessages.map(renderMessage)
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Media Preview */}
      {mediaPreview && (
        <div className="border-t bg-card/50 backdrop-blur">
          <div className="container max-w-4xl mx-auto px-4 py-3 flex items-center gap-3">
            <div className="relative flex-shrink-0">
              {mediaType === 'audio' ? (
                <audio controls className="max-w-xs h-8">
                  <source src={mediaPreview} />
                </audio>
              ) : (
                <img src={mediaPreview} alt="Preview" className="max-h-24 rounded-lg" />
              )}
              <Button
                variant="destructive"
                size="icon"
                className="absolute -top-2 -right-2 h-6 w-6 rounded-full"
                onClick={clearMedia}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground flex-1">
              {mediaType === 'audio' ? 'Áudio selecionado' : 'Imagem selecionada'}
            </p>
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="border-t bg-card sticky bottom-0">
        <div className="container max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => handleMediaSelect(e, 'image')}
            />
            <input
              ref={audioInputRef}
              type="file"
              accept="audio/*"
              className="hidden"
              onChange={(e) => handleMediaSelect(e, 'audio')}
            />
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="rounded-full"
              title="Enviar foto ou GIF"
            >
              <ImageIcon className="h-5 w-5" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => audioInputRef.current?.click()}
              disabled={uploading}
              className="rounded-full"
              title="Enviar áudio"
            >
              <Music className="h-5 w-5" />
            </Button>

            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              placeholder="Digite uma mensagem..."
              className="flex-1 rounded-full"
              maxLength={500}
              disabled={uploading}
            />

            <Button 
              onClick={sendMessage} 
              disabled={uploading || (!inputMessage.trim() && !selectedMedia)}
              className="rounded-full"
              size="icon"
            >
              {uploading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <Send className="h-5 w-5" />
              )}
            </Button>
          </div>
          {inputMessage.length > 0 && (
            <p className="text-xs text-muted-foreground mt-2 text-right">
              {inputMessage.length}/500
            </p>
          )}
        </div>
      </div>

      {/* Setup Modal (First Time) */}
      <Dialog open={showSetupModal} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-md" onInteractOutside={(e) => e.preventDefault()}>
          <DialogHeader>
            <DialogTitle>Bem-vindo ao Chat Global!</DialogTitle>
            <DialogDescription>
              Configure seu perfil para começar a conversar com a comunidade
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {/* Avatar Section */}
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                {tempAvatarPreview ? (
                  <img src={tempAvatarPreview} alt="Avatar" className="w-24 h-24 rounded-full object-cover ring-4 ring-primary/20" />
                ) : (
                  <div className="w-24 h-24 rounded-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center ring-4 ring-primary/20">
                    <User className="w-12 h-12 text-muted-foreground" />
                  </div>
                )}
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarChange}
                />
                <Button
                  variant="secondary"
                  size="sm"
                  className="absolute bottom-0 right-0 rounded-full h-10 w-10 p-0"
                  onClick={() => avatarInputRef.current?.click()}
                >
                  <Upload className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground text-center">
                Foto de perfil (opcional)<br/>Máximo 5MB
              </p>
            </div>

            {/* Username Section */}
            <div>
              <label className="text-sm font-semibold mb-2 block">Nome de usuário</label>
              <Input
                value={tempUsername}
                onChange={(e) => setTempUsername(e.target.value)}
                placeholder="Digite seu nome"
                maxLength={100}
                autoFocus
                onKeyDown={(e) => e.key === 'Enter' && saveProfile()}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Mínimo 1, máximo 100 caracteres
              </p>
            </div>

            <Button 
              onClick={saveProfile} 
              disabled={uploading || !tempUsername.trim()} 
              className="w-full"
              size="lg"
            >
              {uploading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                "Entrar no Chat"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Profile Settings Modal */}
      <Dialog open={showProfileModal} onOpenChange={setShowProfileModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Configurações de Perfil</DialogTitle>
            <DialogDescription>
              Edite seu nome e foto de perfil
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {/* Avatar Section */}
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                {tempAvatarPreview ? (
                  <img src={tempAvatarPreview} alt="Avatar" className="w-24 h-24 rounded-full object-cover ring-4 ring-primary/20" />
                ) : (
                  <div className="w-24 h-24 rounded-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center ring-4 ring-primary/20">
                    <User className="w-12 h-12 text-muted-foreground" />
                  </div>
                )}
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarChange}
                />
                <Button
                  variant="secondary"
                  size="sm"
                  className="absolute bottom-0 right-0 rounded-full h-10 w-10 p-0"
                  onClick={() => avatarInputRef.current?.click()}
                >
                  <Upload className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Username Section */}
            <div>
              <label className="text-sm font-semibold mb-2 block">Nome de usuário</label>
            <Input
              value={tempUsername}
              onChange={(e) => setTempUsername(e.target.value)}
              placeholder="Digite seu nome"
              maxLength={100}
            />
            </div>

            <Button 
              onClick={saveProfile} 
              disabled={uploading || !tempUsername.trim()} 
              className="w-full"
              size="lg"
            >
              {uploading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                "Salvar Alterações"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
