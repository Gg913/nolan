import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import HeroBanner from "@/components/HeroBanner";
import AnimeCarousel from "@/components/AnimeCarousel";
import Footer from "@/components/Footer";
import { Loader2, Play, Clock } from "lucide-react";
import { useWatchProgress } from "@/hooks/useWatchProgress";
import { Link } from "wouter";
import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle, Info, CheckCircle, XCircle } from "lucide-react";

export default function Home() {
  const { data: feedData, isLoading, error } = trpc.anime.getFeed.useQuery();
  const { data: announcements } = trpc.public.getActiveAnnouncements.useQuery();
  const { getContinueWatching, progressData } = useWatchProgress();
  const continueWatching = getContinueWatching().slice(0, 10);
  
  // Re-render quando progressData mudar (atualização em tempo real)
  useEffect(() => {
    // Força re-render
  }, [progressData]);
  
  const [showAnnouncement, setShowAnnouncement] = useState(false);
  const [currentAnnouncementIndex, setCurrentAnnouncementIndex] = useState(0);

  useEffect(() => {
    if (announcements && announcements.length > 0) {
      setShowAnnouncement(true);
    }
  }, [announcements]);

  const handleNextAnnouncement = () => {
    if (announcements && currentAnnouncementIndex < announcements.length - 1) {
      setCurrentAnnouncementIndex(currentAnnouncementIndex + 1);
    } else {
      setShowAnnouncement(false);
      setCurrentAnnouncementIndex(0);
    }
  };

  const getAnnouncementIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-6 w-6 text-green-500" />;
      case "warning":
        return <AlertTriangle className="h-6 w-6 text-yellow-500" />;
      case "error":
        return <XCircle className="h-6 w-6 text-blue-500" />;
      default:
        return <Info className="h-6 w-6 text-blue-500" />;
    }
  };

  const currentAnnouncement = announcements?.[currentAnnouncementIndex];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl text-foreground/80">Erro ao carregar animes</p>
          <p className="text-sm text-muted-foreground mt-2">{error.message}</p>
        </div>
      </div>
    );
  }

  const heroBanner = feedData?.data?.find((item) => item.type === 6);
  const sections = feedData?.data?.filter((item) => [3, 5, 7].includes(item.type || 0));

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Announcement Dialog */}
      {currentAnnouncement && (
        <Dialog open={showAnnouncement} onOpenChange={setShowAnnouncement}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
            <DialogHeader>
              <div className="flex items-center gap-3 mb-2">
                {getAnnouncementIcon(currentAnnouncement.type)}
                <DialogTitle className="text-xl">{currentAnnouncement.title}</DialogTitle>
              </div>
              <DialogDescription className="text-zinc-300 text-base">
                {currentAnnouncement.message}
              </DialogDescription>
            </DialogHeader>
            <div className="flex justify-end gap-2 mt-4">
              {announcements && announcements.length > 1 && (
                <p className="text-sm text-zinc-500 mr-auto">
                  {currentAnnouncementIndex + 1} de {announcements.length}
                </p>
              )}
              <Button
                onClick={handleNextAnnouncement}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {announcements && currentAnnouncementIndex < announcements.length - 1
                  ? "Próximo"
                  : "Entendi"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {heroBanner && (
        <div className="mt-0 md:mt-4">
          <HeroBanner
            animeId={heroBanner.anime_id || 0}
            title={heroBanner.title || ""}
            description={heroBanner.text || ""}
            banner={heroBanner.banner || ""}
            tags={heroBanner.tags}
            year={heroBanner.year}
            rating={heroBanner.rating}
            episodeId={heroBanner.episode_id}
          />
        </div>
      )}

      <div className="px-4 md:px-8 lg:px-12 py-4 md:py-12 space-y-6 md:space-y-12">
        {/* Continue Watching Section */}
        {continueWatching.length > 0 && (
          <div>
            <h2 className="text-xl md:text-2xl font-bold mb-4 md:mb-6 flex items-center gap-2">
              <Clock className="h-6 w-6" />
              Continuar Assistindo
            </h2>
            <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide snap-x snap-mandatory">
              {continueWatching.map((item) => {
                const progressPercent = (item.progress.progress / item.progress.duration) * 100;
                const progressMinutes = Math.floor(item.progress.progress / 60);
                const progressSeconds = Math.floor(item.progress.progress % 60);
                
                return (
                  <Link key={item.episodeId} href={`/watch/${item.episodeId}?t=${Math.floor(item.progress.progress)}`}>
                    <div className="group cursor-pointer flex-shrink-0 w-40 md:w-48 snap-start">
                      <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-muted">
                        <img
                          src={item.progress.animeCover}
                          alt={item.progress.animeTitle}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                        <div className="absolute bottom-0 left-0 right-0 p-3">
                          <div className="flex items-center gap-2 mb-2">
                            <Play className="h-4 w-4 text-primary" />
                            <span className="text-xs font-medium">
                              {item.progress.seasonNumber ? `T${item.progress.seasonNumber} - ` : ''}EP {item.progress.episodeNumber}
                            </span>
                          </div>
                          <p className="text-xs text-white/80 mb-1">
                            {progressMinutes}:{String(progressSeconds).padStart(2, '0')}
                          </p>
                          <div className="w-full bg-white/20 rounded-full h-1">
                            <div
                              className="bg-primary h-1 rounded-full"
                              style={{ width: `${progressPercent}%` }}
                            />
                          </div>
                        </div>
                      </div>
                      <p className="mt-2 text-sm font-medium line-clamp-2">{item.progress.animeTitle}</p>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        )}

        {sections?.map((section, index) => {
          if (!section.title || !section.data) return null;
          
          // Usar formato horizontal apenas para "Lançamentos Recentes" e "Em alta"
          const isHorizontal = section.title.toLowerCase().includes('lançamento') || 
                               section.title.toLowerCase().includes('em alta');
          
          // Episódios novos/recentes devem abrir direto no Watch
          const titleLower = section.title.toLowerCase();
          const linkToWatch = titleLower.includes('lançamento') || 
                              titleLower.includes('episódio') || 
                              titleLower.includes('recente') ||
                              titleLower.includes('novo');
          
          return (
            <AnimeCarousel
              key={`${section.type}-${index}`}
              title={section.title}
              items={section.data}
              format={isHorizontal ? "horizontal" : "vertical"}
              linkToWatch={linkToWatch}
            />
          );
        })}
      </div>

      <Footer />
    </div>
  );
}
