import { useRoute, useLocation, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import VideoPlayer from "@/components/VideoPlayer";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2, Play, ChevronRight, Download } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useEffect, useRef, useState } from "react";
import { useWatchProgress } from "@/hooks/useWatchProgress";

// Fixed React key warning
export default function Watch() {
  const [, params] = useRoute("/watch/:episodeId");
  const [, setLocation] = useLocation();
  const episodeId = parseInt(params?.episodeId || "0");
  const progressSaveInterval = useRef<NodeJS.Timeout | undefined>(undefined);
  const [initialTime, setInitialTime] = useState(0);
  const [showNextEpisode, setShowNextEpisode] = useState(false);
  const { saveProgress: saveWatchProgress, getEpisodeProgress } = useWatchProgress();

  const [loadingTimeout, setLoadingTimeout] = useState(false);
  const [reloadAttempts, setReloadAttempts] = useState(0);
  const MAX_RELOAD_ATTEMPTS = 3;

  const { data: streamData, isLoading } = trpc.anime.getEpisodeStream.useQuery(
    { episodeId },
    { enabled: episodeId > 0 }
  );

  // Auto-reload após 3s de loading (máximo 3 tentativas)
  useEffect(() => {
    if (isLoading) {
      const timeout = setTimeout(() => {
        if (reloadAttempts < MAX_RELOAD_ATTEMPTS) {
          console.log(`Auto-reload tentativa ${reloadAttempts + 1}/${MAX_RELOAD_ATTEMPTS}`);
          setReloadAttempts(prev => prev + 1);
          window.location.reload();
        } else {
          setLoadingTimeout(true);
        }
      }, 3000); // 3 segundos
      return () => clearTimeout(timeout);
    } else {
      setLoadingTimeout(false);
      setReloadAttempts(0); // Resetar contador quando carregar com sucesso
    }
  }, [isLoading, reloadAttempts]);

  const { data: animeData } = trpc.anime.getDetails.useQuery(
    { animeId: streamData?.episodeAnimeID || 0 },
    { enabled: !!streamData?.episodeAnimeID }
  );

  const { data: feedData } = trpc.anime.getFeed.useQuery();

  // Load progress from localStorage using hook OR query parameter ?t=
  useEffect(() => {
    // Resetar initialTime primeiro
    setInitialTime(0);
    
    // Verificar se tem query parameter ?t= na URL
    const searchParams = new URLSearchParams(window.location.search);
    const timeParam = searchParams.get('t');
    
    if (timeParam) {
      // Se tem ?t= na URL, usar esse tempo
      const timeInSeconds = parseInt(timeParam);
      if (!isNaN(timeInSeconds) && timeInSeconds >= 0) {
        setInitialTime(timeInSeconds);
        return; // Não carregar do localStorage
      }
    }
    
    // Se não tem ?t=, carregar do localStorage
    if (streamData?.episodeAnimeID) {
      const progress = getEpisodeProgress(streamData.episodeAnimeID.toString(), episodeId.toString());
      if (progress) {
        setInitialTime(progress.progress);
      }
    }
  }, [episodeId, streamData?.episodeAnimeID, getEpisodeProgress]);

  // Reset showNextEpisode when episodeId changes
  useEffect(() => {
    setShowNextEpisode(false);
  }, [episodeId]);

  useEffect(() => {
    return () => {
      if (progressSaveInterval.current) {
        clearInterval(progressSaveInterval.current);
      }
    };
  }, []);

  const handleVideoProgress = (currentTime: number, duration: number) => {
    // No longer needed - buttons are now permanent
  };

  const lastSaveTimeRef = useRef(0);

  const handleTimeUpdate = (currentTime: number, duration: number) => {
    if (!streamData) return;

    // Salvar a cada 1 segundo (passivo, sem modificar player)
    const now = Date.now();
    if (now - lastSaveTimeRef.current >= 1000) {
      lastSaveTimeRef.current = now;
      
      // Encontrar seasonNumber a partir do animeData
      let seasonNumber: number | undefined;
      if (animeData?.anime_seasons) {
        for (const season of animeData.anime_seasons) {
          if (season.episodes?.some(ep => ep.ep_id === episodeId)) {
            seasonNumber = season.season_number;
            break;
          }
        }
      }
      
      // Save using new hook
      saveWatchProgress(
        streamData.episodeAnimeID.toString(),
        episodeId.toString(),
        Math.floor(currentTime),
        Math.floor(duration),
        streamData.episodeNumber,
        streamData.episodeName || `Episódio ${streamData.episodeNumber}`,
        animeData?.anime_details?.anime_name || "",
        animeData?.anime_details?.anime_cover_url || "",
        seasonNumber // Adicionar temporada
      );
    }
  };

  const handleNextEpisode = () => {
    if (streamData?.nextEpisodeID) {
      setLocation(`/watch/${streamData.nextEpisodeID}`);
    }
  };



  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex flex-col items-center justify-center h-[80vh] gap-4">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          {loadingTimeout && (
            <div className="text-center space-y-2">
              <p className="text-muted-foreground">Carregamento demorado...</p>
              <Button onClick={() => window.location.reload()} variant="outline" size="sm">
                Tentar novamente
              </Button>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (!streamData?.streams) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <p className="text-xl text-foreground/80">Episódio não encontrado</p>
        </div>
      </div>
    );
  }

  const streamUrl = streamData.streams.fhd || streamData.streams.mhd || streamData.streams.shd;

  // Get recommendations from feed - always show popular animes
  const recommendations = feedData?.data
    ?.flatMap((section: any) => section.data || [])
    ?.filter((anime: any) => anime && anime.id && anime.name)
    ?.slice(0, 12) || [];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="pt-16">
        {/* Player Section */}
        <div className="bg-black">
          <div className="container max-w-7xl">
            <div className="py-4 md:py-6">
              <Link href={`/anime/${streamData.episodeAnimeID}`}>
                <Button variant="ghost" className="gap-2 text-white hover:text-white/80 mb-3 md:mb-4">
                  <ArrowLeft className="h-4 w-4" />
                  Voltar para o anime
                </Button>
              </Link>
            </div>

            <div className="aspect-video w-full relative">
              {streamUrl && (
                <VideoPlayer
                  streamUrl={streamUrl}
                  qualities={streamData.streams}
                  initialTime={initialTime}
                  onTimeUpdate={(time, duration) => {
                    handleTimeUpdate(time, duration);
                    handleVideoProgress(time, duration);
                  }}
                  onNextEpisode={handleNextEpisode}
                  hasNextEpisode={streamData.episodeHasNext}
                />
              )}


            </div>

            {/* Navigation Buttons */}
            <div className="py-4 md:py-6 flex flex-col sm:flex-row gap-3">
              {streamData.episodeHasNext && (
                <Button
                  onClick={handleNextEpisode}
                  className="gap-2 w-full sm:flex-1"
                  size="lg"
                >
                  Próximo Episódio
                  <ChevronRight className="h-5 w-5" />
                </Button>
              )}
              
              {/* Botão de Download */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="gap-2 w-full sm:w-auto sm:min-w-[200px]"
                    size="lg"
                  >
                    <Download className="h-5 w-5" />
                    Download MP4
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  {streamData.streams.shd && (
                    <DropdownMenuItem
                      onClick={() => {
                        const fileName = `${animeData?.anime_details?.anime_name || 'Anime'} - Episodio ${streamData.episodeNumber}.mp4`;
                        const encodedUrl = encodeURIComponent(streamData.streams.shd!);
                        const encodedFilename = encodeURIComponent(fileName);
                        window.location.href = `/api/download?url=${encodedUrl}&filename=${encodedFilename}`;
                      }}
                    >
                      480p (SHD)
                    </DropdownMenuItem>
                  )}
                  {streamData.streams.mhd && (
                    <DropdownMenuItem
                      onClick={() => {
                        const fileName = `${animeData?.anime_details?.anime_name || 'Anime'} - Episodio ${streamData.episodeNumber}.mp4`;
                        const encodedUrl = encodeURIComponent(streamData.streams.mhd!);
                        const encodedFilename = encodeURIComponent(fileName);
                        window.location.href = `/api/download?url=${encodedUrl}&filename=${encodedFilename}`;
                      }}
                    >
                      720p (MHD)
                    </DropdownMenuItem>
                  )}
                  {streamData.streams.fhd && (
                    <DropdownMenuItem
                      onClick={() => {
                        const fileName = `${animeData?.anime_details?.anime_name || 'Anime'} - Episodio ${streamData.episodeNumber}.mp4`;
                        const encodedUrl = encodeURIComponent(streamData.streams.fhd!);
                        const encodedFilename = encodeURIComponent(fileName);
                        window.location.href = `/api/download?url=${encodedUrl}&filename=${encodedFilename}`;
                      }}
                    >
                      1080p (FHD)
                    </DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Episode Info */}
            <div className="py-4 md:py-6 space-y-3 md:space-y-4 border-t border-white/10">
              <div>
                <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-white mb-2">
                  {streamData.episodeName}
                </h1>
                <p className="text-sm md:text-base text-white/70">
                  Episódio {streamData.episodeNumber}
                </p>
              </div>
            </div>

            {/* Anime Information */}
            {animeData?.anime_details && (
              <div className="py-4 md:py-6 space-y-4 border-t border-white/10">
                <h2 className="text-lg md:text-xl font-bold text-white">Sobre o Anime</h2>
                
                <div className="space-y-3">
                  <div>
                    <h3 className="text-base md:text-lg font-semibold text-white mb-2">
                      {animeData.anime_details.anime_name}
                    </h3>
                    <p className="text-sm md:text-base text-white/70 leading-relaxed">
                      {animeData.anime_details.anime_description}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {animeData.anime_details.anime_genre?.split(',').map((genre: string, index: number) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-primary/20 text-primary text-xs md:text-sm rounded-full"
                      >
                        {genre.trim()}
                      </span>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    {animeData.anime_details.anime_date && (
                      <div>
                        <p className="text-white/60">Lançamento</p>
                        <p className="text-white font-medium">{animeData.anime_details.anime_date}</p>
                      </div>
                    )}
                    {animeData.anime_details.anime_parental_rating && (
                      <div>
                        <p className="text-white/60">Classificação</p>
                        <p className="text-white font-medium">{animeData.anime_details.anime_parental_rating}</p>
                      </div>
                    )}
                    {animeData.anime_details.release_day && (
                      <div>
                        <p className="text-white/60">Dia de Lançamento</p>
                        <p className="text-white font-medium">{animeData.anime_details.release_day}</p>
                      </div>
                    )}
                    {animeData.anime_details.anime_episodes && (
                      <div>
                        <p className="text-white/60">Episódios</p>
                        <p className="text-white font-medium">{animeData.anime_details.anime_episodes}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Recommendations */}
        {recommendations.length > 0 && (
          <div className="container py-8 md:py-12">
            <h2 className="text-xl md:text-2xl font-bold mb-6">Você também pode gostar</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {recommendations.map((anime: any) => (
                <Link key={anime.id} href={`/anime/${anime.id}`}>
                  <div className="group cursor-pointer">
                    <div className="relative aspect-[2/3] overflow-hidden rounded-lg mb-2">
                      <img
                        src={anime.image}
                        alt={anime.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <h3 className="text-sm font-medium line-clamp-2">{anime.name}</h3>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
