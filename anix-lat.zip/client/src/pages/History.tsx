import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Loader2, Play, Clock, CheckCircle2, Trash2 } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useWatchHistory } from "@/hooks/useWatchHistory";

export default function History() {
  const [, setLocation] = useLocation();
  const { history, clearHistory: clearAll, removeAnime } = useWatchHistory();

  // Group by anime
  const groupedHistory = new Map<number, typeof history>();
  history.forEach((item) => {
    const existing = groupedHistory.get(item.animeId) || [];
    groupedHistory.set(item.animeId, [...existing, item]);
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container py-8 md:py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Meu Histórico</h1>
            <p className="text-foreground/70">Continue assistindo de onde parou</p>
          </div>
          {history.length > 0 && (
            <Button
              variant="outline"
              onClick={() => {
                if (confirm("Tem certeza que deseja limpar todo o histórico?")) {
                  clearAll();
                }
              }}
              className="gap-2"
            >
              <Trash2 className="h-4 w-4" />
              Limpar Tudo
            </Button>
          )}
        </div>

        {history.length === 0 ? (
          <div className="text-center py-20">
            <Clock className="h-20 w-20 mx-auto mb-4 text-muted-foreground" />
            <p className="text-xl text-foreground/80 mb-2">
              Você ainda não assistiu nenhum episódio
            </p>
            <p className="text-foreground/60 mb-6">
              Comece a assistir seus animes favoritos agora!
            </p>
            <Button onClick={() => setLocation("/")} size="lg">
              Explorar Animes
            </Button>
          </div>
        ) : (
          <div className="space-y-8">
            {Array.from(groupedHistory.entries()).map(([animeId, episodes]) => {
              const latestEpisode = episodes[0]; // Most recent episode

              return (
                <div key={animeId} className="space-y-4">
                  {/* Anime Header */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold">{latestEpisode.animeName}</h2>
                      <p className="text-sm text-muted-foreground">
                        {episodes.length} episódio{episodes.length > 1 ? "s" : ""} assistido{episodes.length > 1 ? "s" : ""}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        if (confirm(`Remover "${latestEpisode.animeName}" do histórico?`)) {
                          removeAnime(animeId);
                        }
                      }}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Remover Anime
                    </Button>
                  </div>

                  {/* Episodes Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
                    {episodes.map((item) => {
                      const progressPercent = (item.currentTime / item.duration) * 100;

                      return (
                        <Link key={item.episodeId} href={`/watch/${item.episodeId}`}>
                          <div className="group cursor-pointer">
                            <div className="relative aspect-video rounded-lg overflow-hidden bg-muted">
                              {item.animeImage ? (
                                <img
                                  src={item.animeImage}
                                  alt={`Episódio ${item.episodeNumber}`}
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                  <Play className="h-8 w-8 text-muted-foreground" />
                                </div>
                              )}

                              {/* Play Overlay */}
                              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <div className="bg-primary rounded-full p-3">
                                  <Play className="h-6 w-6 text-primary-foreground fill-current" />
                                </div>
                              </div>

                              {/* Completed Badge */}
                              {item.completed && (
                                <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded-full text-xs font-semibold flex items-center gap-1">
                                  <CheckCircle2 className="h-3 w-3" />
                                </div>
                              )}

                              {/* Progress Bar */}
                              <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/50">
                                <div
                                  className="h-full bg-primary transition-all"
                                  style={{ width: `${progressPercent}%` }}
                                />
                              </div>
                            </div>

                            <div className="mt-2 space-y-1">
                              <p className="text-sm font-medium">Episódio {item.episodeNumber}</p>
                              <div className="flex items-center justify-between text-xs text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  {Math.floor(item.currentTime / 60)} / {Math.floor(item.duration / 60)} min
                                </span>
                                <span>
                                  {new Date(item.timestamp).toLocaleDateString("pt-BR", {
                                    day: "2-digit",
                                    month: "short",
                                  })}
                                </span>
                              </div>
                            </div>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
