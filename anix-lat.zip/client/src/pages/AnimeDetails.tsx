import { useRoute, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Play, Heart, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";
import { useState, useEffect } from "react";
import { useWatchProgress } from "@/hooks/useWatchProgress";

export default function AnimeDetails() {
  const [, params] = useRoute("/anime/:id");
  const animeId = parseInt(params?.id || "0");
  const [expandedSeasons, setExpandedSeasons] = useState<Record<number, boolean>>({});
  const [isFavorite, setIsFavorite] = useState(false);

  const { data: animeData, isLoading } = trpc.anime.getDetails.useQuery(
    { animeId },
    { enabled: animeId > 0 }
  );

  // Check if anime is in favorites (localStorage)
  useEffect(() => {
    const favoritesKey = `favorites`;
    const favorites = JSON.parse(localStorage.getItem(favoritesKey) || "[]");
    setIsFavorite(favorites.some((fav: any) => fav.animeId === animeId));
  }, [animeId]);

  const toggleFavorite = () => {
    const favoritesKey = `favorites`;
    const favorites = JSON.parse(localStorage.getItem(favoritesKey) || "[]");
    
    if (isFavorite) {
      // Remove from favorites
      const newFavorites = favorites.filter((fav: any) => fav.animeId !== animeId);
      localStorage.setItem(favoritesKey, JSON.stringify(newFavorites));
      setIsFavorite(false);
      toast.success("Removido dos favoritos!");
    } else {
      // Add to favorites
      const newFavorite = {
        animeId,
        animeName: animeData?.anime_details?.anime_name || "",
        animeCape: animeData?.anime_details?.anime_cape_url || "",
        addedAt: new Date().toISOString(),
      };
      favorites.unshift(newFavorite);
      localStorage.setItem(favoritesKey, JSON.stringify(favorites));
      setIsFavorite(true);
      toast.success("Adicionado aos favoritos!");
    }
  };

  const toggleSeason = (seasonId: number) => {
    setExpandedSeasons(prev => ({
      ...prev,
      [seasonId]: !prev[seasonId]
    }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!animeData?.anime_details) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <p className="text-xl text-foreground/80">Anime não encontrado</p>
        </div>
      </div>
    );
  }

  const anime = animeData.anime_details;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <div className="relative h-[50vh] md:h-[60vh] overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={anime.anime_banner_url}
            alt={anime.anime_name}
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        </div>
        
        <div className="relative container h-full flex items-end pb-6 md:pb-12">
          <div className="flex flex-col md:flex-row gap-3 md:gap-6 items-start md:items-end w-full">
            <img
              src={anime.anime_cover_url}
              alt={anime.anime_name}
              className="w-28 h-40 md:w-40 md:h-60 object-cover rounded-lg shadow-2xl flex-shrink-0"
            />
            <div className="flex-1">
              <h1 className="text-2xl md:text-4xl lg:text-5xl font-bold mb-2 md:mb-4">
                {anime.anime_name}
              </h1>
              <div className="flex flex-wrap gap-2 mb-3 md:mb-4 text-xs md:text-sm text-foreground/80">
                <span className="bg-primary/20 text-primary px-2 py-1 rounded">
                  {anime.anime_parental_rating}
                </span>
                <span>{anime.anime_date}</span>
                <span>•</span>
                <span>{anime.anime_episodes} episódios</span>
                {anime.release_day && (
                  <>
                    <span>•</span>
                    <span>{anime.release_day}</span>
                  </>
                )}
              </div>
              <div className="flex flex-wrap gap-2 mb-4">
                <Button
                  size="lg"
                  className="bg-primary hover:bg-primary/90"
                  onClick={() => {
                    const firstSeason = animeData.anime_seasons?.[0];
                    if (firstSeason) {
                      toggleSeason(firstSeason.season_id);
                      // Scroll to seasons
                      setTimeout(() => {
                        document.getElementById('seasons')?.scrollIntoView({ behavior: 'smooth' });
                      }, 100);
                    }
                  }}
                >
                  <Play className="w-5 h-5 mr-2" />
                  Assistir
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={toggleFavorite}
                  className={isFavorite ? "bg-primary/20 border-primary" : ""}
                >
                  <Heart className={`w-5 h-5 mr-2 ${isFavorite ? "fill-primary" : ""}`} />
                  {isFavorite ? "Favoritado" : "Favoritar"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container py-8 md:py-12">
        {/* Description */}
        <div className="mb-8 md:mb-12">
          <h2 className="text-xl md:text-2xl font-bold mb-4">Sinopse</h2>
          <p className="text-sm md:text-base text-foreground/80 leading-relaxed">
            {anime.anime_description}
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {anime.anime_genre.split(",").map((genre: string, index: number) => (
              <span
                key={index}
                className="text-xs md:text-sm bg-accent px-3 py-1 rounded-full text-foreground/80"
              >
                {genre.trim()}
              </span>
            ))}
          </div>
        </div>

        {/* Seasons */}
        <div id="seasons">
          <h2 className="text-xl md:text-2xl font-bold mb-4 md:mb-6">Episódios</h2>
          <div className="space-y-4">
            {animeData.anime_seasons?.map((season: any) => (
              <SeasonCard
                key={season.season_id}
                season={season}
                animeId={animeId}
                animeName={anime.anime_name}
                animeCover={anime.anime_cover_url}
                isExpanded={expandedSeasons[season.season_id]}
                onToggle={() => toggleSeason(season.season_id)}
              />
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

function SeasonCard({ 
  season, 
  animeId,
  animeName,
  animeCover,
  isExpanded, 
  onToggle 
}: {
  season: any;
  animeId: number;
  animeName: string;
  animeCover: string;
  isExpanded: boolean;
  onToggle: () => void;
}) {
  const [currentPage, setCurrentPage] = useState(0);
  const [allEpisodes, setAllEpisodes] = useState<any[]>([]);
  const [hasMore, setHasMore] = useState(true);
  const { isEpisodeWatched, getEpisodeProgress } = useWatchProgress();

  const { data: episodesData, isLoading, refetch } = trpc.anime.getSeasonEpisodes.useQuery(
    { seasonId: season.season_id, page: currentPage, order: "ASC" },
    { 
      enabled: false, // Não carregar automaticamente
      refetchOnMount: false,
      refetchOnWindowFocus: false
    }
  );

  // Carregar primeira página quando expandir
  useEffect(() => {
    if (isExpanded && allEpisodes.length === 0) {
      refetch();
    }
  }, [isExpanded]);

  // Atualizar lista quando dados chegarem
  useEffect(() => {
    if (episodesData?.data) {
      if (episodesData.data.length === 0) {
        setHasMore(false);
      } else {
        setAllEpisodes(prev => [...prev, ...episodesData.data]);
        // Se retornou menos episódios que o esperado, provavelmente não há mais
        if (episodesData.data.length < 20) {
          setHasMore(false);
        }
      }
    }
  }, [episodesData]);

  const loadMore = () => {
    setCurrentPage(prev => prev + 1);
    // Aguardar atualização do estado e então fazer refetch
    setTimeout(() => {
      refetch();
    }, 100);
  };

  // Não resetar ao fechar - manter episódios carregados

  return (
    <div className="bg-card rounded-lg overflow-hidden border border-border">
      <button
        onClick={onToggle}
        className="w-full px-4 md:px-6 py-3 md:py-4 flex items-center justify-between hover:bg-accent/50 transition"
      >
        <div className="flex items-center gap-3 md:gap-4">
          <h3 className="text-base md:text-lg font-semibold text-left">{season.season_name}</h3>
          {season.season_dubbed === 1 && (
            <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded">
              Dublado
            </span>
          )}
        </div>
        {isExpanded ? (
          <ChevronUp className="w-5 h-5 flex-shrink-0" />
        ) : (
          <ChevronDown className="w-5 h-5 flex-shrink-0" />
        )}
      </button>

      {isExpanded && (
        <div className="border-t border-border">
          {isLoading && allEpisodes.length === 0 ? (
            <div className="p-8 flex items-center justify-center">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : allEpisodes.length > 0 ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4 p-4 md:p-6">
                {allEpisodes.map((episode: any) => {
                  const progress = getEpisodeProgress(animeId.toString(), episode.ep_id.toString());
                  const watched = isEpisodeWatched(animeId.toString(), episode.ep_id.toString());
                  const progressPercent = progress ? (progress.progress / progress.duration) * 100 : 0;

                  return (
                    <Link key={episode.ep_id} href={`/watch/${episode.ep_id}`}>
                      <div className="group block bg-background rounded-lg overflow-hidden hover:ring-2 hover:ring-primary transition">
                        <div className="relative aspect-video">
                          <img
                            src={episode.ep_thumbnail}
                            alt={episode.ep_name}
                            className="w-full h-full object-cover"
                          />
                          {watched && (
                            <div className="absolute top-2 right-2 bg-primary text-white text-xs px-2 py-1 rounded">
                              ✓ Assistido
                            </div>
                          )}
                          {progress && !watched && (
                            <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/50">
                              <div 
                                className="h-full bg-primary transition-all"
                                style={{ width: `${progressPercent}%` }}
                              />
                            </div>
                          )}
                          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/60 transition flex items-center justify-center">
                            <Play className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition" />
                          </div>
                        </div>
                        <div className="p-3">
                          <p className="text-xs md:text-sm font-semibold text-foreground/60 mb-1">
                            Episódio {episode.ep_number}
                          </p>
                          <h4 className="text-sm md:text-base font-medium line-clamp-2">
                            {episode.ep_name}
                          </h4>
                          <div className="flex items-center justify-between mt-1">
                            <p className="text-xs text-foreground/60">
                              {episode.ep_lenght_minutes} min
                            </p>
                            {progress && !watched && (
                              <p className="text-xs text-primary">
                                {Math.floor(progress.progress / 60)}:{String(Math.floor(progress.progress % 60)).padStart(2, '0')}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    </Link>
                  );
                })}
              </div>
              
              {hasMore && (
                <div className="p-4 flex justify-center border-t border-border">
                  <Button
                    onClick={loadMore}
                    disabled={isLoading}
                    variant="outline"
                    className="w-full md:w-auto"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Carregando...
                      </>
                    ) : (
                      <>
                        <ChevronDown className="w-4 h-4 mr-2" />
                        Mostrar mais episódios
                      </>
                    )}
                  </Button>
                </div>
              )}
            </>
          ) : (
            <div className="p-8 text-center text-foreground/60">
              Nenhum episódio disponível
            </div>
          )}
        </div>
      )}
    </div>
  );
}
