import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Heart, Clock, Trash2, Play, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { useWatchProgress } from "@/hooks/useWatchProgress";

interface FavoriteItem {
  animeId: number;
  animeName: string;
  animeCape: string;
  addedAt: string;
}

export default function Profile() {
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);
  const { getContinueWatching, removeProgress } = useWatchProgress();
  const continueWatching = getContinueWatching(); // Mostrar TODOS os animes
  
  // Get all progress from localStorage
  const allProgress = JSON.parse(localStorage.getItem("anix_watch_progress") || "{}");

  useEffect(() => {
    const favoritesData = JSON.parse(localStorage.getItem("favorites") || "[]");
    setFavorites(favoritesData);
  }, []);

  const clearAllData = () => {
    if (confirm("Tem certeza que deseja limpar todos os seus dados (favoritos e histórico)?")) {
      localStorage.removeItem("favorites");
      localStorage.removeItem("anix_watch_progress");
      setFavorites([]);
      window.location.reload();
    }
  };

  // Calculate stats - contar apenas episódios em progresso (não 100% assistidos)
  const totalEpisodesWatched = continueWatching.length;

  const totalWatchTime = Object.values(allProgress).reduce((acc: number, anime: any) => {
    return acc + Object.values(anime).reduce((sum: number, ep: any) => sum + (ep.progress || 0), 0);
  }, 0);

  const totalWatchHours = Math.floor(totalWatchTime / 3600);
  const totalWatchMinutes = Math.floor((totalWatchTime % 3600) / 60);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container py-24 md:py-32">
        {/* Hero Header */}
        <div className="relative mb-12 md:mb-16">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-transparent rounded-2xl blur-3xl -z-10" />
          <div className="bg-gradient-to-br from-zinc-900 to-black border border-zinc-800 rounded-2xl p-8 md:p-12">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-3 bg-gradient-to-r from-white to-zinc-400 bg-clip-text text-transparent">
                  Meu Perfil
                </h1>
                <p className="text-zinc-400 text-lg">
                  Seus dados locais salvos no navegador
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br from-primary to-blue-700 rounded-full flex items-center justify-center">
                  <span className="text-2xl md:text-3xl font-bold">
                    {favorites.length > 0 ? favorites[0].animeName.charAt(0).toUpperCase() : "U"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-12 md:mb-16">
          <div className="group relative bg-gradient-to-br from-zinc-900 to-black border border-zinc-800 rounded-xl p-6 hover:border-primary/50 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 rounded-xl transition-opacity" />
            <div className="relative flex items-center gap-4">
              <div className="p-3 bg-primary/20 rounded-lg group-hover:scale-110 transition-transform">
                <Heart className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-3xl font-bold">{favorites.length}</p>
                <p className="text-sm text-zinc-400">Favoritos</p>
              </div>
            </div>
          </div>

          <div className="group relative bg-gradient-to-br from-zinc-900 to-black border border-zinc-800 rounded-xl p-6 hover:border-primary/50 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 rounded-xl transition-opacity" />
            <div className="relative flex items-center gap-4">
              <div className="p-3 bg-primary/20 rounded-lg group-hover:scale-110 transition-transform">
                <Play className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-3xl font-bold">{totalEpisodesWatched}</p>
                <p className="text-sm text-zinc-400">Episódios Assistidos</p>
              </div>
            </div>
          </div>

          <div className="group relative bg-gradient-to-br from-zinc-900 to-black border border-zinc-800 rounded-xl p-6 hover:border-primary/50 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 rounded-xl transition-opacity" />
            <div className="relative flex items-center gap-4">
              <div className="p-3 bg-primary/20 rounded-lg group-hover:scale-110 transition-transform">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-3xl font-bold">{totalWatchHours}h {totalWatchMinutes}m</p>
                <p className="text-sm text-zinc-400">Tempo Assistido</p>
              </div>
            </div>
          </div>
        </div>

        {/* Continue Watching */}
        {continueWatching.length > 0 && (
          <div className="mb-12 md:mb-16">
            <div className="flex items-center gap-3 mb-6">
              <TrendingUp className="h-6 w-6 text-primary" />
              <h2 className="text-2xl md:text-3xl font-bold">Continuar Assistindo</h2>
            </div>

            <div className="flex overflow-x-auto scrollbar-hide gap-4 pb-4 snap-x snap-mandatory">
              {continueWatching.map((item) => {
                const progressPercent = (item.progress.progress / item.progress.duration) * 100;
                const progressMinutes = Math.floor(item.progress.progress / 60);
                const progressSeconds = Math.floor(item.progress.progress % 60);
                
                return (
                  <div key={item.episodeId} className="group cursor-pointer relative flex-shrink-0 w-40 md:w-48 snap-start">
                    {/* Botão Remover */}
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        if (confirm(`Remover "${item.progress.animeTitle}" do histórico?`)) {
                          removeProgress(item.animeId, item.episodeId);
                        }
                      }}
                      className="absolute top-2 right-2 z-10 bg-black/80 hover:bg-blue-600 text-white rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Remover do histórico"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                    
                    <Link href={`/watch/${item.episodeId}?t=${Math.floor(item.progress.progress)}`}>
                      <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-zinc-900 border border-zinc-800 hover:border-primary/50 transition-all">
                        <img
                          src={item.progress.animeCover}
                          alt={item.progress.animeTitle}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
                        <div className="absolute bottom-0 left-0 right-0 p-3">
                          <div className="flex items-center gap-2 mb-2">
                            <Play className="h-3 w-3 text-primary" />
                            <span className="text-xs font-medium">
                              {item.progress.seasonNumber ? `T${item.progress.seasonNumber} - ` : ''}EP {item.progress.episodeNumber}
                            </span>
                          </div>
                          <p className="text-xs text-white/80 mb-1">
                            {progressMinutes}:{String(progressSeconds).padStart(2, '0')}
                          </p>
                          <div className="w-full bg-white/20 rounded-full h-1">
                            <div
                              className="bg-primary h-1 rounded-full"
                              style={{ width: `${progressPercent}%` }}
                            />
                          </div>
                        </div>
                      </div>
                      <p className="mt-2 text-sm font-medium line-clamp-2">{item.progress.animeTitle}</p>
                    </Link>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Favorites */}
        <div className="mb-12 md:mb-16">
          <div className="flex items-center gap-3 mb-6">
            <Heart className="h-6 w-6 text-primary" />
            <h2 className="text-2xl md:text-3xl font-bold">Meus Favoritos</h2>
          </div>

          {favorites.length === 0 ? (
            <div className="text-center py-20 bg-gradient-to-br from-zinc-900 to-black rounded-2xl border border-zinc-800">
              <Heart className="h-16 w-16 mx-auto mb-4 text-zinc-700" />
              <p className="text-xl text-zinc-300 mb-2">Você ainda não tem favoritos</p>
              <p className="text-sm text-zinc-500">
                Adicione animes aos favoritos para vê-los aqui
              </p>
            </div>
          ) : (
            <div className="flex overflow-x-auto scrollbar-hide gap-4 pb-4 snap-x snap-mandatory">
              {favorites.map((fav) => (
                <Link key={fav.animeId} href={`/anime/${fav.animeId}`}>
                  <div className="group cursor-pointer flex-shrink-0 w-32 md:w-40 snap-start">
                    <div className="relative aspect-[2/3] overflow-hidden rounded-lg mb-2 bg-zinc-900 border border-zinc-800 hover:border-primary/50 transition-all">
                      {fav.animeCape ? (
                        <img
                          src={fav.animeCape}
                          alt={fav.animeName}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Heart className="h-8 w-8 text-zinc-700" />
                        </div>
                      )}
                    </div>
                    <h3 className="text-sm font-medium line-clamp-2">{fav.animeName}</h3>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Data Management */}
        <div className="bg-gradient-to-br from-zinc-900 to-black border border-zinc-800 rounded-2xl p-8">
          <div className="flex items-start gap-4 mb-6">
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <Trash2 className="h-6 w-6 text-blue-500" />
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold mb-2">Gerenciar Dados</h2>
              <p className="text-sm text-zinc-400 mb-4">
                Todos os seus dados (favoritos e histórico) são salvos localmente no seu navegador.
                Eles não são sincronizados entre dispositivos.
              </p>
              <Button
                variant="destructive"
                onClick={clearAllData}
                className="gap-2"
              >
                <Trash2 className="h-4 w-4" />
                Limpar Todos os Dados
              </Button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
