import { useState, useEffect } from "react";

export interface EpisodeProgress {
  progress: number; // segundos assistidos
  duration: number; // duração total em segundos
  timestamp: number; // quando foi salvo
  episodeNumber: number;
  seasonNumber?: number; // temporada do episódio
  episodeTitle: string;
  animeTitle: string;
  animeCover: string;
}

export interface AnimeProgress {
  [episodeId: string]: EpisodeProgress;
}

export interface WatchProgressData {
  [animeId: string]: AnimeProgress;
}

const STORAGE_KEY = "anix_watch_progress";

export function useWatchProgress() {
  const [progressData, setProgressData] = useState<WatchProgressData>({});

  // Carregar dados do localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setProgressData(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Erro ao carregar progresso:", error);
    }
  }, []);

  // Salvar progresso de um episódio
  const saveProgress = (
    animeId: string,
    episodeId: string,
    progress: number,
    duration: number,
    episodeNumber: number,
    episodeTitle: string,
    animeTitle: string,
    animeCover: string,
    seasonNumber?: number
  ) => {
    setProgressData((prev) => {
      const updated = {
        ...prev,
        [animeId]: {
          ...(prev[animeId] || {}),
          [episodeId]: {
            progress,
            duration,
            timestamp: Date.now(),
            episodeNumber,
            seasonNumber,
            episodeTitle,
            animeTitle,
            animeCover,
          },
        },
      };

      // Salvar no localStorage
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error("Erro ao salvar progresso:", error);
      }

      return updated;
    });
  };

  // Obter progresso de um episódio específico
  const getEpisodeProgress = (animeId: string, episodeId: string): EpisodeProgress | null => {
    return progressData[animeId]?.[episodeId] || null;
  };

  // Obter último episódio assistido de um anime
  const getLastWatchedEpisode = (animeId: string): { episodeId: string; progress: EpisodeProgress } | null => {
    const animeProgress = progressData[animeId];
    if (!animeProgress) return null;

    let lastEpisode: { episodeId: string; progress: EpisodeProgress } | null = null;
    let latestTimestamp = 0;

    Object.entries(animeProgress).forEach(([episodeId, progress]) => {
      if (progress.timestamp > latestTimestamp) {
        latestTimestamp = progress.timestamp;
        lastEpisode = { episodeId, progress };
      }
    });

    return lastEpisode;
  };

  // Obter todos os animes com progresso (para "Continue Assistindo")
  const getContinueWatching = (): Array<{ animeId: string; episodeId: string; progress: EpisodeProgress }> => {
    const result: Array<{ animeId: string; episodeId: string; progress: EpisodeProgress }> = [];

    Object.entries(progressData).forEach(([animeId, episodes]) => {
      const lastEpisode = getLastWatchedEpisode(animeId);
      if (lastEpisode) {
        // Só mostrar se não assistiu mais de 90% (se assistiu tudo, não mostrar)
        const percentWatched = (lastEpisode.progress.progress / lastEpisode.progress.duration) * 100;
        if (percentWatched < 90) {
          result.push({
            animeId,
            episodeId: lastEpisode.episodeId,
            progress: lastEpisode.progress,
          });
        }
      }
    });

    // Ordenar por timestamp mais recente
    result.sort((a, b) => b.progress.timestamp - a.progress.timestamp);

    return result;
  };

  // Verificar se episódio foi assistido (mais de 90%)
  const isEpisodeWatched = (animeId: string, episodeId: string): boolean => {
    const progress = getEpisodeProgress(animeId, episodeId);
    if (!progress) return false;

    const percentWatched = (progress.progress / progress.duration) * 100;
    return percentWatched >= 90;
  };

  // Remover progresso de um episódio específico
  const removeProgress = (animeId: string, episodeId: string) => {
    setProgressData((prev) => {
      const updated = { ...prev };
      
      if (updated[animeId]) {
        delete updated[animeId][episodeId];
        
        // Se não sobrou nenhum episódio, remover o anime também
        if (Object.keys(updated[animeId]).length === 0) {
          delete updated[animeId];
        }
      }

      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error("Erro ao remover progresso:", error);
      }

      return updated;
    });
  };

  // Limpar progresso de um anime
  const clearAnimeProgress = (animeId: string) => {
    setProgressData((prev) => {
      const updated = { ...prev };
      delete updated[animeId];

      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error("Erro ao limpar progresso:", error);
      }

      return updated;
    });
  };

  return {
    saveProgress,
    getEpisodeProgress,
    getLastWatchedEpisode,
    getContinueWatching,
    isEpisodeWatched,
    removeProgress,
    clearAnimeProgress,
    progressData, // Expor para reatividade
  };
}
